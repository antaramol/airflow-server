##################################################################
### Exceptions
##################################################################


### Imports
##################################################################

# Data Reader Error Codes
ExceptionErrorCodes = {
    "invalid_asset":"[1 - Invalid Asset]",
    "invalid_date":"[2 - Invalid Dates]",
    "invalid_tags":"[3 - Invalid Tag List]",
    "invalid_download_mode":"[4 - Invalid Download Mode]",
    "read_error":"[5 - Read Error]",
    "data_error":"[6 - No Data]",
    "write_file":"[7 - Writing Output File]",
    "invalid_parameter":"[8 - Invalid Input Parameters]",
    "breeze_extractor_error":"[9 - Breeze Extractor Error]",
    "pi_webapi_error":"[10 - PI Web API Error]",
    "pi_webapi_credential":"[11 - PI Web API Credential Failed]"
}


class DataReaderError(Exception):
    """ Base error exception.
    """
    def __init__(self,message):
        self.message = message

# class InvalidAssetException(DataReaderError):
#     """ Asset not in asset definition list.
#     """
#     def __init__(self,message):
#         self.message = message

# class InvalidAssetType(DataReaderError):
#     """ Asset type not correspond to asset class
#     """
#     def __init__(self,message):
#         self.message = message


# class InvalidCredentialFile(DataReaderError):
#     """ Asset type not correspond to asset class
#     """
#     def __init__(self,message):
#         self.message = message


# class InvalidDateFormat(DataReaderError):
#     """ Asset type not correspond to asset class
#     """
#     def __init__(self,message):
#         self.message = message

# class InvalidDownloadMode(DataReaderError):
#     """ Asset type not correspond to asset class
#     """
#     def __init__(self,message):
#         self.message = message

# class InvalidDateRange(DataReaderError):
#     """ Asset type not correspond to asset class
#     """
#     def __init__(self,message):
#         self.message = message

# class TimeIntervalException(DataReaderError):
#     """ Asset type not correspond to asset class
#     """
#     def __init__(self,message):
#         self.message = message


# class InvalidDataReturned(DataReaderError):
#     """ Asset type not correspond to asset class
#     """
#     def __init__(self,message):
#         self.message = message

# class InvalidExtractorFunction(DataReaderError):
#     """ Access function is not allowed for asset
#     """

#     def __init__(self,message):
#         self.message = message