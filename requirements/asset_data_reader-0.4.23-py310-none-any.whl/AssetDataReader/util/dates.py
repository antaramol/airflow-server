###################################################################
### Dates helper functions
###################################################################


### Imports
###################################################################

# Generic imports
import json
import datetime as dt
from dateutil.relativedelta import relativedelta
import pandas as pd
import time
# import pytz
from zoneinfo import ZoneInfo

# Own imports
from AssetDataReader.util.exceptions import ExceptionErrorCodes
from AssetDataReader.util.exceptions import DataReaderError


### Functions
###################################################################

def _tokenize( string, categories ):
    """
    from: http://blog.thehumangeo.com/2015/01/07/string-tokenization/ 
    
    Given a string and a list of category, return category tokens
    present in the string.

    param string: target string to tokenize
    param categories: target categories to look for

    return list of tokens found in target string
    """

    token = ''
    tokens = []
    category = None
    for char in string:
        if token:
            if category and char in category:
                token += char
            else:
                tokens.append( token )
                token = char
                category = None
                for cat in categories:
                    if char in cat:
                        category = cat
                        break
        else:
            category = None
            if not category:
                for cat in categories:
                    if char in cat:
                        category = cat
                        break
            token += char
    if token:
        tokens.append( token )
    return tokens

def _get_start_date(marker,asset_definition):
    """ Get start date from a Referenced Time expression.

    param marker: definition of start point
    param asset_definition: asset parameters for time zone conversion

    return datetime with the start time of the Referneced Time
    """

    try:
        # Get start date
        returned_date = dt.datetime.utcnow()

        # Convert to local time
        # tz_origin = pytz.timezone('UTC')
        # tz_to = pytz.timezone(asset_definition['time_zone'])
        tz_origin = ZoneInfo('UTC')
        tz_to = ZoneInfo(asset_definition['time_zone'])

        returned_date = tz_origin.localize(returned_date)
        returned_date = returned_date.astimezone(tz_to)
        
        returned_date = dt.datetime(returned_date.year,returned_date.month,returned_date.day,
            returned_date.hour,returned_date.minute,returned_date.second)

        # Mark start point
        if marker == "*":
            pass
        elif marker == "t":
            returned_date = returned_date.replace(hour=0,minute=0,second=0)
        elif marker == "y":
            returned_date = returned_date.replace(hour=0,minute=0,second=0)
            returned_date -= dt.timedelta(days=1)
        else:
            return None

        return returned_date

    except:
        return None


def _chunks(lst, n):
    """ Given a list, return a splited list generator in n-length chunks

    param lst: target list
    param n: length of each chunk

    return splited list of n-length-chunks (list)
    """
    for i in range(0, len(lst), n):
        yield lst[i:i + n]

def _apply_operator(returned_date,operator_action,operator_cuantity,operator_unit):
    """ Apply a operation to a target date

    param returned_date: target date to apply operator
    param operator_action: operation to perfom to target date
    param operator_cuantity: amount of units
    param operator_unit: time unit of the operation

    return datetime with the operation performed
    """

    # Define factor
    if operator_unit == "s": # seconds
        dt_op = dt.timedelta(seconds=operator_cuantity)
    elif operator_unit == "m": # minutes
        dt_op = dt.timedelta(minutes=operator_cuantity)
    elif operator_unit == "h": # hours
        dt_op = dt.timedelta(hours=operator_cuantity)
    elif operator_unit == "d": # days
        dt_op = dt.timedelta(days=operator_cuantity)
    elif operator_unit == "w": # weeks
        dt_op = dt.timedelta(weeks=operator_cuantity)
    elif operator_unit == "mo": # months
        dt_op = relativedelta(months=operator_cuantity)
    elif operator_unit == "y": # years
        dt_op = relativedelta(years=operator_cuantity)
        
    else:
        return None
    
    # Apply factor
    if operator_action == "-": # substract oepration
        return returned_date - dt_op
    elif operator_action == "+": # add operation
        return returned_date + dt_op
    else:
        return None

def _parse_referenced_date(target_date,asset_definition):
    """ Given a Referenced Time, return a datetime object with
    the interpretation of the Referenced Time

    param target_date: referenced time to interpret
    param asset_definition: asset definition with timezone for time conversion

    return datetime with referenced time interpreted
    """

    # Tokenize referenced time and check if correct
    tokens = _tokenize( target_date, ['0123456789.', '*','+','-','abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'] )
    if len(tokens) != 1 and (len(tokens[1:]) % 3) != 0: # If len not mataches with single date + <operators>
        return None
    
    # Parse referenced time
    try:
        # Get start point
        returned_date = _get_start_date(tokens[0],asset_definition)
        if returned_date != None:

            # Apply operator if needed
            operators = list(_chunks(tokens[1:],3))            
            for operator in operators:               
                returned_date = _apply_operator(returned_date,operator[0],float(operator[1]),operator[2])
        else:
            return None

        return returned_date

    except:
        return None




def _parse_date(target_date,asset_definition):
    """ Get date in datetime format.

    param target_date: target date to parse
    param asset_definition: asset definition with timezone for time conversion in 
        referenced time.

    return target date in datetime format if correct. None if wrong date format 
    """

    if type(target_date == 'str'):
        
        # Try fixed time
        try: 
            return dt.datetime.strptime(target_date, '%Y-%m-%dT%H:%M:%S')
        except Exception: # Try referenced time
            return _parse_referenced_date(target_date,asset_definition)
    
    elif type(target_date) == dt.datetime:
        return target_date
    
    else:
        return None

def get_date_range(date_from,date_to,asset_definition):
    """ Given two dates in both Fixed or Referenced Time format
    return a tuple with a correct daterange parsed

    param date_from: start date
    param date_to: end date
    param asset_definition: asset definition with timezone for Referenced
        Time convsersion

    return a tuple with interpreted start-end date
    """

    # Parse date from
    dt_from = _parse_date(date_from,asset_definition)
    if dt_from is None:
        error_msg = "%s Date from (%s) has no valid format" % (ExceptionErrorCodes["invalid_date"],date_from)
        raise DataReaderError(error_msg)

    # Parse date to
    dt_to = _parse_date(date_to,asset_definition)
    if dt_to is None:
        error_msg = "%s Date to (%s) has no valid format" % (ExceptionErrorCodes["invalid_date"],date_to)
        raise DataReaderError(error_msg)

    # Check invalid date range
    if dt_to < dt_from:
        error_msg = "%s Date from (%s) must be earlier or equal to Date to (%s)" % (ExceptionErrorCodes["invalid_date"],date_from,date_to)
        raise DataReaderError(error_msg)

    return dt_from,dt_to
