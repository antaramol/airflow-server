##################################################################
### File and Data Parsers Help Functions
##################################################################


### Imports
##################################################################

# Generic imports
import json
import datetime as dt
import pandas as pd
import time
# import pytz

# Own imports
from AssetDataReader.extractor.PIWebAPIExtractor import PIWebAPIExtractor
from AssetDataReader.extractor.PIWebServiceExtractor import PIWebServiceExtractor
from AssetDataReader.extractor.BreezeAPIExtractor import BreezeAPIExtractor

from AssetDataReader.config.AssetDefinition import AssetDefinitionList

from AssetDataReader.util.exceptions import ExceptionErrorCodes
from AssetDataReader.util.exceptions import DataReaderError


### Constants
###################################################################
ASSET_ID_MAPPING= {
    "ACT": "ACT"
    ,"Cadonal": "Cadonal"
    ,"Calgary": "Calgary"
    ,"Estrellada": "Estrellada"
    ,"Helioenergy 1": "HelioEnergy"
    ,"Helioenergy 2": "HelioEnergy"
    ,"HelioEnergy 1": "HelioEnergy"
    ,"HelioEnergy 2": "HelioEnergy"
    ,"Helioenergy": "HelioEnergy"
    ,"Helios 1": "Helios"
    ,"Helios 2": "Helios"
    ,"Kaxu": "Kaxu"
    ,"Mojave Alpha": "Mojave"
    ,"Mojave Beta": "Mojave"
    ,"Palmatir": "Palmatir"
    ,"Quadra": "Quadra"
    ,"San Pedro": "San Pedro"
    ,"Solaben 1": "Solaben"
    ,"Solaben 2": "Solaben"
    ,"Solaben 3": "Solaben"
    ,"Solaben 6": "Solaben"
    ,"Solacor 1": "Solacor"
    ,"Solacor 2": "Solacor"
    ,"Solana": "Solana"
    ,"Solnova 1": "Solucar"
    ,"Solnova 3": "Solucar"
    ,"Solnova 4": "Solucar"
    ,"PS 10": "Solucar"
    ,"PS 20": "Solucar"
    ,"Sevilla PV": "Solucar"
}

### Functions
###################################################################

def get_asset(asset_id):
    """ Get asset definition with Asset ID

    param asset_id: Asset ID in AssetDefinition File.
    
    return dict with asset definition.
    """

    # Read JSON configuration file
    # with open("config/AssetDefinition.json","r") as f:
    #     asset_definitions = json.loads(f.read())


    ## Match asset with inner assets
    if asset_id in list(ASSET_ID_MAPPING.keys()):
        final_asset_id = ASSET_ID_MAPPING[asset_id]
    else:
        final_asset_id = asset_id

    # Get asset definition
    try:
        asset_list = [item for item in AssetDefinitionList if item["id"] == final_asset_id]
        if len(asset_list) == 1:
            return asset_list[0]
        return None
    except Exception:
        return None
    

def create_breeze_extractor(asset_definition):
    """ Select Extractor Client by type

    param asset_definition: asset definition

    return extractor from asset definition
    """

    # Create extarctor based on type
    if asset_definition['type'] == 'breeze_api':
        return BreezeAPIExtractor(asset_definition)
    
    return None

def create_pi_extractor(asset_definition,piaf_user,piaf_pwd,piaf_credential_file):
    """ Select Extractor Client by type

    param asset_definition: asset definition

    return extractor from asset definition
    """

    # Create extarctor based on type
    if asset_definition['type'] == 'pi_api':
        return PIWebAPIExtractor(asset_definition,piaf_user,piaf_pwd,piaf_credential_file)
    elif asset_definition['type'] == 'pi_service':
        return PIWebServiceExtractor(asset_definition)
    
    return None


def parse_tag_list(tag_list_file):
    """ Parse an EXCEL or JSON tag list file

    param tag_list_file: path to tag list file

    return tag list in JSON format
    """

    try:
        
        # Load tag list
        if type(tag_list_file) == list:
            parsed_tags = tag_list_file
        else:
            file_extension = tag_list_file.split(".")[-1]
            if file_extension == "xlsx":
                df_tags = pd.read_excel(tag_list_file)
                parsed_tags = json.loads(df_tags.to_json(orient="records"))
            elif file_extension == 'csv':
                df_tags = pd.read_csv(tag_list_file)
                parsed_tags = json.loads(df_tags.to_json(orient="records"))
            elif file_extension == 'json':
                with open(tag_list_file,"r") as f:
                    parsed_tags = json.loads(f.read())
            else:
                raise Exception("No valid or not found file. Only .xlsx, .csv or .json files are supported.")

        # Process tag list
        for i in range(len(parsed_tags)):
            if not "descriptor" in list(parsed_tags[i].keys()):
                parsed_tags[i].update({"descriptor":""})

        just_tags = [x['tag'] for x in parsed_tags]
        seen = set()
        duplicates = [x for x in just_tags if x in seen or seen.add(x)]    
        if len(duplicates) > 0:
            msg = "Duplicated tags:\n->"+"\n->".join(duplicates)
            raise Exception(msg)

        return parsed_tags
    except Exception as e:
        error_msg = "%s %s is an invalid tag list. Error: %s" % (ExceptionErrorCodes["invalid_tags"], tag_list_file,e)
        raise DataReaderError(error_msg)
    


def pretty_time(seconds):
    """ Format seconds in hours, minutes and seconds string format

    param seconds: total seconds
    
    return string with hours, minutes and seconds format
    """

    pretty_str = ""
    s_aux = seconds

    # Parse hour
    if int(s_aux/3600) != 0:
        pretty_str += "%dh " % (int(s_aux/3600))
        s_aux = s_aux % 3600
    
    if int(s_aux/60) != 0:
        pretty_str += "%dm " % (int(s_aux/60))
        s_aux = s_aux % 60
    
    pretty_str += "%ds" % (s_aux)

    return pretty_str

