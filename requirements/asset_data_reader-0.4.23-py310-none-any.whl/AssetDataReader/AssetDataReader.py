##################################################################
### Asset Data Reader for Atlantica Assets
##################################################################
#
# This class is the Abstarct class and entry methdo for the whole
# library. Its purpose is to serve as a handle function for 
# reading data from Atlantiva assets appart from other useful
# information suchas asset definition.
#
##################################################################

# Generic imports
import pandas as pd
# import pytz
import datetime as dt
import time
import os
import numpy as np
from zoneinfo import ZoneInfo

# Osisoft imports
# from osisoft.pidevclub.piwebapi.pi_web_api_client import PIWebApiClient

# Own imports
from AssetDataReader.util.parser import get_asset
from AssetDataReader.util.parser import create_breeze_extractor
from AssetDataReader.util.parser import create_pi_extractor
from AssetDataReader.util.parser import parse_tag_list
from AssetDataReader.util.parser import pretty_time
from AssetDataReader.util.dates import get_date_range

from AssetDataReader.config.AssetDefinition import AssetDefinitionList

# Exception imports
from AssetDataReader.util.exceptions import ExceptionErrorCodes
from AssetDataReader.util.exceptions import DataReaderError


def read_breeze_data(asset_definition,dt_from,dt_to,tag_list,time_interval,time_range_download,download_mode,mode,include_units,local_time,verbose,on_error_continue,on_error_attemps):
    """ Perform data extraction from Breeze Asset.

    param asset_definition: ASI asset definition.
    param dt_from: str or datetime with start time to download.
    param dt_to: str or datetime with end time to download.
    param tag_list: dict or file path (EXCEL or CSV) tag list to download.
    param time_interval: (default None)  time frequency expression in PI format. If not 
        None, interpolated values will be returned.
    param download_mode: (default interpolated): where to download interpolated or recorded data.
    param mode: (default long) dataframe structure format: long or wide.
    param local_time: (default False) if True, timestamp will be returned in asset local timestamp.
    param verbose: flag to indicate if verbosing output.
    param on_error_continue: flag to indicate if return results when a batch fails.

    return dataframe with requested data
    """
    
    # Select Extractor
    extractor = create_breeze_extractor(asset_definition)

    ## Do extraction
    # Download data
    if download_mode in ["average","sum","counter"]: 
        df_data = extractor.read_data_values(dt_from,dt_to,tag_list,time_interval,time_range_download,download_mode,mode,include_units,verbose,on_error_continue,on_error_attemps)

    # Download status
    elif download_mode == "status":
        df_data = extractor.read_status_values(dt_from,dt_to,tag_list,verbose,on_error_continue,on_error_attemps)

    # Download alarms
    elif download_mode == "alarms":
        df_data = extractor.read_alarms_values(dt_from,dt_to,tag_list,verbose,on_error_continue,on_error_attemps)

    # Error in download mode
    else:
        error_msg = "%s '%s' is not supported for Breeze Extractor. Must be one of 'average', 'sum', 'counter', 'status' or 'alarms'" % (ExceptionErrorCodes["invalid_download_mode"],download_mode)
        raise DataReaderError(error_msg)


    # If data returned, process time columns    
    if not df_data.empty:

        if download_mode in ['status','alarms']:
            time_tags = ['start_time','end_time']
        else:
            time_tags = ['time']


        for time_tag in time_tags:
            # Convert to requested time zone if needed
            # tz_origin = pytz.timezone(asset_definition['time_zone'])
            # tz_to = pytz.timezone('UTC')
            tz_origin = ZoneInfo(asset_definition['time_zone'])
            tz_to = ZoneInfo('UTC')
            df_data[time_tag] = pd.to_datetime(df_data[time_tag]).dt.tz_localize(tz_origin)
            if not local_time:
                df_data[time_tag] = df_data[time_tag].dt.tz_convert(tz_to)

        ## Check missed columns
        if mode == "wide" and download_mode not in ['status','alarms']:
            requested_columns = [x['tag'].replace(" ","_") if x['descriptor'] != '' else x['tag'].replace(" ","_") for x in tag_list]
            missed_columns = [x for x in requested_columns if True not in[x in item for item in df_data.columns]] # Check if requested columns is at least part of each columns
            for col in missed_columns:
                df_data[col] = np.nan    

            # Sort columns again
            new_col_order = ['time'] + sorted([x for x in df_data.columns if x != "time"])
            df_data = df_data[new_col_order]
    
    return df_data


def read_pi_data(asset_definition,dt_from,dt_to,tag_list,download_mode,calculation,calculation_time_tag,calculation_basis,
        time_interval,time_range_download,filter_expression,mode,include_units,local_time,piaf_user,
        piaf_pwd,piaf_credential_file,verbose,on_error_continue,on_error_attemps):
    """ Perform data extraction from PI Asset.

    param asset_definition: ASI asset definition.
    param dt_from: str or datetime with start time to download.
    param dt_to: str or datetime with end time to download.
    param tag_list: dict or file path (EXCEL or CSV) tag list to download.
    param download_mode: download mode available on asset data server service.
    param calculation (default None): calculation Osisoft type if needed.
    param calculation_time_tag (default None): calculation Osisoft time type to download.
    param time_interval: (default None)  time frequency expression in Asset Data Server Format.
    param filter_expression: (default None) filter expression for PI Data Servers.
    param mode: (default long) dataframe structure format: long or wide.
    param local_time: (default False) if True, timestamp will be returned in asset local timestamp.
    param verbose: flag to indicate if verbosing output.
    param on_error_continue: flag to indicate if return results when a batch fails.

    return dataframe with requested data
    """

    # #LOG FILE
    if verbose >= 4:
        os.makedirs("data_reader_logs",exist_ok=True)
        os.makedirs(f"data_reader_logs/call",exist_ok=True)

    # Select Extractor
    extractor = create_pi_extractor(asset_definition,piaf_user,piaf_pwd,piaf_credential_file)

    # Do extraction

    # Download recorded values
    if download_mode == 'recorded':
        if time_interval == None:
            time_interval = "1s"
        df_data = extractor.read_recorded_values(dt_from,dt_to,tag_list,time_interval,time_range_download,filter_expression,mode,include_units,verbose,on_error_continue,on_error_attemps)

    # Download interpolated values
    elif download_mode == 'interpolated':
        if time_interval == None:
            error_msg = "%s Time interval is needed for interpolated downloads" % (ExceptionErrorCodes["invalid_parameter"])
            raise DataReaderError(error_msg)
        df_data = extractor.read_interpolated_values(dt_from,dt_to,tag_list,time_interval,time_range_download,filter_expression,mode,include_units,verbose,on_error_continue,on_error_attemps)
    
    # Donwload calculated values
    elif download_mode == 'calculated':
        if time_interval == None:
            error_msg = "%s Time interval is needed for calculated downloads" % (ExceptionErrorCodes["invalid_parameter"])
            raise DataReaderError(error_msg)
        
        if calculation == None:
            error_msg = "%s Calculation type is needed for calculated downloads" % (ExceptionErrorCodes["invalid_parameter"])
            raise DataReaderError(error_msg)
        
        if calculation_time_tag == None:
            error_msg = "%s Calculation time is needed for calculated downloads" % (ExceptionErrorCodes["invalid_parameter"])
            raise DataReaderError(error_msg)

        df_data = extractor.read_calculated_values(dt_from,dt_to,tag_list,time_interval,time_range_download,calculation,calculation_time_tag,calculation_basis,filter_expression,mode,include_units,verbose,on_error_continue,on_error_attemps)
    
    # elif download_mode == 'uom':
    #     df_data = extractor.read_unit_values(dt_from,dt_to,tag_list,verbose,on_error_continue)

    elif download_mode == "get_pipoints":
        if asset_definition['type'] == 'pi_service':
            error_msg = "%s '%s' is not supported for not PI-AF Servers." % (ExceptionErrorCodes["invalid_download_mode"],download_mode)
            raise DataReaderError(error_msg)

        df_data = extractor.read_pipoints_from_path(tag_list,verbose,on_error_continue,on_error_attemps)

    elif download_mode == "get_descriptors":
        if asset_definition['type'] == 'pi_service':
            error_msg = "%s '%s' is not supported for not PI-AF Servers." % (ExceptionErrorCodes["invalid_download_mode"],download_mode)
            raise DataReaderError(error_msg)

        df_data = extractor.read_descriptor_from_point(tag_list,verbose,on_error_continue,on_error_attemps)

    
    elif download_mode == "get_last_value":
        df_data = extractor.read_last_value(tag_list,verbose=verbose,on_error_continue=on_error_continue,on_error_attempts=on_error_attemps)

    else:
        error_msg = "%s '%s' is not supported for PI Extractor. Must be one of 'interpolated', 'recorded','calculated', 'get_pipoints' or 'get_descriptors" % (ExceptionErrorCodes["invalid_download_mode"],download_mode)
        raise DataReaderError(error_msg)


    # If data returned, process time columns 
    if not df_data.empty and download_mode not in ["get_pipoints","get_descriptors"]:
        # Do time zone conversion if needed
        # tz_origin = pytz.timezone('UTC')
        # tz_to = pytz.timezone(asset_definition['time_zone'])
        tz_origin = ZoneInfo('UTC')
        tz_to = ZoneInfo(asset_definition['time_zone'])

        #if (not local_time and asset_definition['id'] in ['Palmatir','Cadonal']) or (local_time and not asset_definition['id'] in ['Palmatir','Cadonal']):
        if local_time:
            if (download_mode == 'recorded' and mode == "wide") or (download_mode == "calculated" and calculation_time_tag == 'Auto' and mode == "wide"):
                time_features = list(filter(lambda x: ("time|" in x),list(df_data.columns)))
                for time_feature in time_features:
                    df_data[time_feature] = pd.to_datetime(df_data[time_feature]).dt.tz_localize(tz_origin)
                    df_data[time_feature] = df_data[time_feature].dt.tz_convert(tz_to)

            else:
                #tz_local = pytz.timezone(asset_definition['time_zone'])
                df_data['time'] = pd.to_datetime(df_data['time']).dt.tz_localize(tz_origin)
                df_data['time'] = df_data['time'].dt.tz_convert(tz_to)
        else:
            if (download_mode == 'recorded' and mode == "wide") or (download_mode == "calculated" and calculation_time_tag == 'Auto' and mode == "wide"):
                time_features = list(filter(lambda x: ("time|" in x),list(df_data.columns)))
                for time_feature in time_features:
                    df_data[time_feature] = pd.to_datetime(df_data[time_feature]).dt.tz_localize(tz_origin)
            else:
                df_data['time'] = pd.to_datetime(df_data['time']).dt.tz_localize(tz_origin)

        ## Check missed columns
        if mode == "wide" and download_mode != "get_last_value":

            # requested_columns = [f"{x['descriptor']}|"+x['tag'].replace("\\","_") if x['descriptor'] != '' else x['tag'] for x in tag_list]
            requested_columns = []
            for x in tag_list:
                ## Check if PIDA or PIAF tag
                if "\\" in x['tag']: # PIAF
                    target_tag = x['tag'].replace("\\","_")[1:]
                else: # PIDA
                    target_tag = x['tag']
                
                final_tag = f"{x['descriptor']}|{target_tag}"  if x['descriptor'] != '' else target_tag
                requested_columns.append(final_tag)


            part_time = (download_mode == 'recorded' and mode == "wide") or (download_mode == "calculated" and calculation_time_tag == 'Auto' and mode == "wide")
            if part_time:
                requested_columns += [f"time|{x}" for x in requested_columns]
            
            # Add to DF and sotr colums by values
            missed_columns = [x for x in requested_columns if True not in[x in item for item in df_data.columns]] # Check if requested columns is at least part of each columns
            for col in missed_columns:
                df_data[col] = np.nan    

            # Sort columns again
            new_col_order = ['time'] + sorted([x for x in df_data.columns if x != "time"]) if not part_time else sorted(df_data.columns)
            df_data = df_data[new_col_order]
            

    # # LOG FILE
    if verbose >= 4:
        os.rename("data_reader_logs/call",f"data_reader_logs/call_{dt.datetime.now().strftime('%Y%m%d_%H%M%S')}")

    return df_data



###################################################################
### Asset Reader Abstract Class
###################################################################

class AssetDataReader:
    """ (Abstract) Atlantica Sustainable Infraestructure (ASI Asset Reader)

    This class includes wrapper methods for reading data
    from Atlantica Sustainable Infraestructure assets

    """

    @staticmethod
    def get_asset_definition(asset):
        """ Giving an asset ID, return full asset definition.

        param asset: asset ID.

        return asset definition in JSON format.
        """
        asset_definition = get_asset(asset)
        if asset_definition is None:
            error_msg = "%s %s not in Asset Definition List" % (ExceptionErrorCodes["invalid_asset"],asset)
            raise DataReaderError(error_msg)
        
        return asset_definition
    
    @staticmethod
    def get_asset_definition_list():
        """ Return full asset definition list

        return asset definition list in JSON format.
        """

        return AssetDefinitionList
    
    @staticmethod
    def convert_time(serie,tz_from_def,tz_to_def):
        """ Given a time series and Time Zones,
        return a serie with converted time

        param serie: target serie to convert.
        param tz_from_def: time zone for time series
        param tz_to_def: time zone to convert

        return time series with converted time
        """
        # tz_from = pytz.timezone(tz_from_def)
        # tz_to = pytz.timezone(tz_to_def)
        tz_from = ZoneInfo(tz_from_def)
        tz_to = ZoneInfo(tz_to_def)

        localized_serie = serie.dt.tz_localize(tz_from)
        return localized_serie.dt.tz_convert(tz_to)

    
    
    @staticmethod
    def read_asset_data (
        asset,
        tag_list,
        date_from=None,
        date_to=None,
        download_mode=None,
        file_name=None,
        calculation="Average",
        calculation_time_tag="EarliestTime",
        calculation_basis="TimeWeighted",
        time_interval=None,
        time_range_download=False,
        filter_expression=None,
        mode='long',
        include_units=False,
        local_time=False,
        include_timezone=True,
        piaf_user=None,
        piaf_pwd=None,
        piaf_credential_file=None,
        verbose=False,
        on_error_continue=False,
        on_error_attempts=10,
        just_descriptor=False
        ):
        """ Perform Download Action

        param asset: ASI asset indentifier in config file.
        param date_from: str or datetime with start time to download.
        param date_to: str or datetime with end time to download.
        param tag_list: dict or file path (EXCEL or CSV) tag list to download.
        param download_mode: download mode available on asset data server service.
        param file_name: (default None) target file name for csv export. If None, no file
            will be created.
        param calculation (default None): calculation Osisoft type if needed.
        param calculation_time_tag (default None): calculation Osisoft time type to download.
        param time_interval: (default None)  time frequency expression in Asset Data Server Format.
        param filter_expression: (default None) filter expression for PI Data Servers.
        param mode: (default long) dataframe structure format: long or wide.
        param local_time: (default False) if True, timestamp will be returned in asset local timestamp.
        param verbose: flag to indicate if verbosing output.
        param on_error_continue: flag to indicate if return results when a batch fails.

        return dataframe with requested data
        return target file name saved if needed
        """

        # Control time for verbose
        start_time = time.time()

        # Get asset definition from config
        asset_definition = get_asset(asset)

        # Control error for invalid asset
        if asset_definition is None:
            error_msg = "%s %s not in Asset Definition List" % (ExceptionErrorCodes["invalid_asset"],asset)
            raise DataReaderError(error_msg)

        # Parse dates
        if date_from != None and date_to != None:
            dt_from, dt_to = get_date_range(date_from,date_to,asset_definition)
        else:
            dt_from = None
            dt_to = None


        # Parse tag lsit
        tag_list = parse_tag_list(tag_list)

        # Switch parameters
        if time_range_download:
            time_range_download_parsed = "memory_saving"
        else:
            time_range_download_parsed = None


        # Download Data
        #---------------------------------------------------------------------------

        if asset_definition['type'] == "breeze_api":
            df_data = read_breeze_data(asset_definition,dt_from,dt_to,tag_list,time_interval,time_range_download_parsed,download_mode,mode,include_units,local_time,verbose,on_error_continue,on_error_attempts)

        elif asset_definition['type'] in ['pi_api','pi_service']:
            df_data =  read_pi_data(asset_definition,dt_from,dt_to,tag_list,download_mode,calculation,calculation_time_tag,calculation_basis,time_interval,time_range_download_parsed,filter_expression,mode,include_units,local_time,piaf_user,piaf_pwd,piaf_credential_file,verbose,on_error_continue,on_error_attempts)

        #---------------------------------------------------------------------------


        ## Process common
        if not include_timezone:
            df_data['time'] = df_data['time'].dt.tz_localize(None)

        if just_descriptor:
            if mode == "wide":
                df_data.rename(columns={x:x.split("|")[0] for x in df_data.columns if x != "time"},inplace=True)
            else:
                mapping = {x:x.split("|")[0] for x in list(df_data['tag'].unique())}
                df_data['tag'] = df_data['tag'].map(mapping)


        # Write file if requested
        try:
            if file_name != None and file_name != "":
                target_file_name = "%s_%s.csv" % (file_name.split(".")[0],dt.datetime.now().strftime("%Y%m%d_%H%M%S"))
                time_features = list(filter(lambda x: ("time|" in x),list(df_data.columns)))
                time_features = time_features if len(time_features) > 0 else ["time"]
                for time_feature in time_features:
                    df_data[time_feature] = df_data[time_feature].apply(str).str.replace(" ","T")
                df_data.to_csv(target_file_name,header=True,index=False)
            else:
                target_file_name = None
        
        except Exception as e:
            error_msg = "%s %s" % (ExceptionErrorCodes["write_file"],str(e))
            raise DataReaderError(error_msg)
        
        if verbose:
            print("Download finished.")
            print("Total time: %s" % (pretty_time(time.time()-start_time)))

        return df_data,target_file_name