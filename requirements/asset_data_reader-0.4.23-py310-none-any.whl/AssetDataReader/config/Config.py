####################################################
### COMMON DOWNLOAD DEFINITION PARAMETERS
####################################################

ConnectionErrorAttemps = {
    "max_attemps":10,
    "time_to_sleep":30
}

BreezeConfig = {
    "max_days_per_batch": 10
}

PiWebAPIConfig = {
    "batcher":{
        "max_days":30,
        "max_tags":10,
        "max_items":100000,
        "max_count":150000
    }
}

PiWebServiceConfig = {
    "batcher":{
        "max_days":30,
        "max_tags":10,
        "max_items":100000
    }
}