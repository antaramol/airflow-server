# Asset Definition

AssetDefinitionList = [
    {
        "id": "AssetModel-DES",
        "type": "pi_api",
        "server_endpoint": "https://ayazuvpiaf01des.atlanticayield.com/piwebapi",
        "pi_data_server": "",
        "pi_af_server": "AYAZUVPIAF01DES",
        "pi_af_database": "AYAssetsModel-DES",
        "time_zone": "UTC"
    },
    {
        "id": "Alarms",
        "type": "pi_api",
        "server_endpoint": "https://ayazuvpiaf01.atlanticayield.com/piwebapi",
        "pi_data_server": "AYAZUVPIAF01",
        "pi_af_server": "AYAZUVPIAF01",
        "pi_af_database": "Alarms",
        "time_zone": "UTC"
    },
    {
        "id": "Alarms-DES",
        "type": "pi_api",
        "server_endpoint": "https://ayazuvpiaf01des.atlanticayield.com/piwebapi",
        "pi_data_server": "AYAZUVPIAF01",
        "pi_af_server": "AYAZUVPIAF01DES",
        "pi_af_database": "Atlantica-DEV",
        "time_zone": "UTC"
    },
    {
        "id": "Mojave",
        "type": "pi_api",
        "server_endpoint": "https://aymojapiaf01.atlanticayield.com/piwebapi",
        "pi_data_server": "mohabsapp01.atlanticayield.com",
        "pi_af_server": "AYMOJAPIAF01",
        "pi_af_database": "Mojave",
        "time_zone": "US/Pacific"
    },
    {
        "id": "Mojave-DES",
        "type": "pi_api",
        "server_endpoint": "https://ayazuvpiaf01des.atlanticayield.com/piwebapi",
        "pi_data_server": "mohabsapp01.atlanticayield.com",
        "pi_af_server": "AYAZUVPIAF01DES",
        "pi_af_database": "Mojave-DES",
        "time_zone": "US/Pacific"
    },
    {
        "id": "Solana",
        "type": "pi_api",
        "server_endpoint": "https://ayslnpiaf01.atlanticayield.com/piwebapi",
        "pi_data_server": "gilsolapp01.atlanticayield.com",
        "pi_af_server": "AYSLNPIAF01",
        "pi_af_database": "Solana",
        "time_zone": "US/Arizona"
    },
    {
        "id": "Solana-DES",
        "type": "pi_api",
        "server_endpoint": "https://ayazuvpiaf01des.atlanticayield.com/piwebapi",
        "pi_data_server": "gilsolapp01.atlanticayield.com",
        "pi_af_server": "AYAZUVPIAF01DES",
        "pi_af_database": "Solana-DES",
        "time_zone": "US/Arizona"
    },
    {
        "id": "Kaxu",
        "type": "pi_api",
        "server_endpoint": "https://aypofpiaf01.atlanticayield.com/piwebapi",
        "pi_data_server": "pofabsapp01.atlanticayield.com",
        "pi_af_server": "AYPOFPIAF01",
        "pi_af_database": "Kaxu",
        "time_zone": "Africa/Johannesburg"
    },
    {
        "id": "Kaxu-DES",
        "type": "pi_api",
        "server_endpoint": "https://ayazuvpiaf01des.atlanticayield.com/piwebapi",
        "pi_data_server": "pofabsapp01.atlanticayield.com",
        "pi_af_server": "AYAZUVPIAF01DES",
        "pi_af_database": "Kaxu-DES",
        "time_zone": "Africa/Johannesburg"
    },
    {
        "id": "ACT",
        "type": "pi_api",
        "server_endpoint": "https://ayvilpiaf01.atlanticayield.com/piwebapi",
        "pi_data_server": "VILACTAPP02",
        "pi_af_server": "AYVILPIAF01",
        "pi_af_database": "ACT",
        "time_zone": "America/Mexico_City"
    },
    {
        "id": "ACT-DES",
        "type": "pi_api",
        "server_endpoint": "https://ayazuvpiaf01des.atlanticayield.com/piwebapi",
        "pi_data_server": "VILACTAPP02",
        "pi_af_server": "AYAZUVPIAF01DES",
        "pi_af_database": "ACT-DES",
        "time_zone": "America/Mexico_City"
    },

    {
        "id": "Calgary",
        "type": "pi_api",
        "server_endpoint": "https://ayazuvpiaf01.atlanticayield.com/piwebapi",
        "pi_data_server": "AYAZUVPIAF01",
        "pi_af_server": "AYAZUVPIAF01",
        "pi_af_database": "CDHI",
        "time_zone": "Canada/Mountain"
    },

    {
        "id": "Helios",
        "type": "pi_api",
        "server_endpoint": "https://ayhelpiaf01.atlanticayield.com/piwebapi",
        "pi_data_server": "creabsapp01.atlanticayield.com",
        "pi_af_server": "AYHELPIAF01",
        "pi_af_database": "HELIOS",
        "time_zone": "Europe/Madrid"
    },
    {
        "id": "Solucar",
        "type": "pi_api",
        "server_endpoint": "https://aysolpiaf01.atlanticayield.com/piwebapi",
        "pi_data_server": "srv-solucontrol.atlanticayield.com",
        "pi_af_server": "AYSOLPIAF01",
        "pi_af_database": "SOLUCAR",
        "time_zone": "Europe/Madrid"
    },
    {
        "id": "Solaben",
        "type": "pi_api",
        "server_endpoint": "https://ayslbpiaf01.atlanticayield.com/piwebapi",
        "pi_data_server": "cacabsapp01.atlanticayield.com",
        "pi_af_server": "AYSLBPIAF01",
        "pi_af_database": "SOLABEN",
        "time_zone": "Europe/Madrid"
    },
    {
        "id": "Solacor",
        "type": "pi_api",
        "server_endpoint": "https://ayslcpiaf01.atlanticayield.com/piwebapi",
        "pi_data_server": "corabsapp01.atlanticayield.com",
        "pi_af_server": "AYSLCPIAF01",
        "pi_af_database": "SOLACOR",
        "time_zone": "Europe/Madrid"
    },
    {
        "id": "HelioEnergy",
        "type": "pi_api",
        "server_endpoint": "https://ayhlypiaf01.atlanticayield.com/piwebapi",
        "pi_data_server": "eciabeapp01.atlanticayield.com",
        "pi_af_server": "AYHLYPIAF01",
        "pi_af_database": "HELIOENERGY",
        "time_zone": "Europe/Madrid"
    },
    {
        "id": "Helios-SOAP",
        "type": "pi_service",
        "server_endpoint": "http://ayazuvpiapi01.atlanticayield.com/PIWebServices/PITimeSeries.svc",
        "server_host": "ayazuvpiapi01.atlanticayield.com",
        "pi_data_server": "creabsapp01.atlanticayield.com",
        "time_zone": "Europe/Madrid"
    },
    {
        "id": "Solucar-SOAP",
        "type": "pi_service",
        "server_endpoint": "http://ayazuvpiapi01.atlanticayield.com/PIWebServices/PITimeSeries.svc",
        "server_host": "ayazuvpiapi01.atlanticayield.com",
        "pi_data_server": "srv-solucontrol.atlanticayield.com",
        "time_zone": "Europe/Madrid"
    },
    {
        "id": "Solaben-SOAP",
        "type": "pi_service",
        "server_endpoint": "http://ayazuvpiapi01.atlanticayield.com/PIWebServices/PITimeSeries.svc",
        "server_host": "ayazuvpiapi01.atlanticayield.com",
        "pi_data_server": "cacabsapp01.atlanticayield.com",
        "time_zone": "Europe/Madrid"
    },
    {
        "id": "Solacor-SOAP",
        "type": "pi_service",
        "server_endpoint": "http://ayazuvpiapi01.atlanticayield.com/PIWebServices/PITimeSeries.svc",
        "server_host": "ayazuvpiapi01.atlanticayield.com",
        "pi_data_server": "corabsapp01.atlanticayield.com",
        "time_zone": "Europe/Madrid"
    },
    {
        "id": "HelioEnergy-SOAP",
        "type": "pi_service",
        "server_endpoint": "http://ayazuvpiapi01.atlanticayield.com/PIWebServices/PITimeSeries.svc",
        "server_host": "ayazuvpiapi01.atlanticayield.com",
        "pi_data_server": "eciabeapp01.atlanticayield.com",
        "time_zone": "Europe/Madrid"
    },
    {
        "id": "Palmatir",
        "type": "breeze_api",
        "windfarm": "Peralta",
        "api_url": "https://atlanticayield.greenbyte.cloud/api/2.0/",
        "api_key": "78289c04ad3348ff98e598534da7af85",
        "time_zone": "America/Montevideo"
    },
    {
        "id": "Palmatir-PI",
        "type": "pi_api",
        "server_endpoint": "https://ayazuvpiaf01.atlanticayield.com/piwebapi",
        "pi_data_server": "AYAZUVPIAF01",
        "pi_af_server": "AYAZUVPIAF01",
        "pi_af_database": "Palmatir",
        "time_zone": "America/Montevideo"
    },
    {
        "id": "Cadonal",
        "type": "breeze_api",
        "windfarm": "Talas de Maciel II",
        "api_url": "https://atlanticayield.greenbyte.cloud/api/2.0/",
        "api_key": "78289c04ad3348ff98e598534da7af85",
        "time_zone": "America/Montevideo"
    },
    {
        "id": "Cadonal-PI",
        "type": "pi_api",
        "server_endpoint": "https://ayazuvpiaf01.atlanticayield.com/piwebapi",
        "pi_data_server": "AYAZUVPIAF01",
        "pi_af_server": "AYAZUVPIAF01",
        "pi_af_database": "Cadonal",
        "time_zone": "America/Montevideo"
    },
    {
        "id": "Estrellada",
        "type": "breeze_api",
        "windfarm": "Melowind",
        "api_url": "https://atlanticayield.greenbyte.cloud/api/2.0/",
        "api_key": "78289c04ad3348ff98e598534da7af85",
        "time_zone": "America/Montevideo"
    },
    {
        "id": "Estrellada-PI",
        "type": "pi_api",
        "server_endpoint": "https://ayazuvpiaf01.atlanticayield.com/piwebapi",
        "pi_data_server": "AYAZUVPIAF01",
        "pi_af_server": "AYAZUVPIAF01",
        "pi_af_database": "Estrellada",
        "time_zone": "America/Montevideo"
    },
    {
        "id": "San Pedro",
        "type": "pi_api",
        "server_endpoint": "https://ayazuvpiaf01.atlanticayield.com/piwebapi",
        "pi_data_server": "AYAZUVPIAF01",
        "pi_af_server": "AYAZUVPIAF01",
        "pi_af_database": "SanPedro_v0",
        "time_zone": "Chile/Continental"
    },
    {
        "id": "Mejillones",
        "type": "pi_api",
        "server_endpoint": "https://ayazuvpiaf01.atlanticayield.com/piwebapi",
        "pi_data_server": "AYAZUVPIAF01",
        "pi_af_server": "AYAZUVPIAF01",
        "pi_af_database": "Alarms",
        "time_zone": "Chile/Continental"
    },
                {
        "id": "Baquedano",
        "type": "pi_api",
        "server_endpoint": "https://ayazuvpiaf01.atlanticayield.com/piwebapi",
        "pi_data_server": "AYAZUVPIAF01",
        "pi_af_server": "AYAZUVPIAF01",
        "pi_af_database": "Baquedano IEC104",
        "time_zone": "Chile/Continental"
    }

]