##################################################################
### Base Data Extractor
##################################################################


### Imports
##################################################################

# Generic imports
import pandas as pd

### Base extractor class
###################################################################

class BaseDataExtractor:
    """ Atlantica Sustainable Infraestructure (ASI) Base Extractor

    This class serves as a template for developing a data extractor that
    can be integrated in ASI Asset Data Reader

    """


    def __init__(self):
        """ Base constructor.
        """
        pass
    
    def read_recorded_values(self,date_from,date_to,tag_list):
        """ Read recorded values in server

        return dataframe with requested data
        """
        pass
    
    def read_interpolated_values(self,date_from,date_to,tag_list,time_step,mode='long'):
        """ Read interpoalted values in server
        
        return dataframe with requested data
        """
        pass
    
    def read_calculated_values(self,date_from,date_to,tag_list,time_interval,calculation,calculation_time_tag,mode='long'):
        """ Read calculated values in server
        
        return dataframe with requested data
        """
        pass