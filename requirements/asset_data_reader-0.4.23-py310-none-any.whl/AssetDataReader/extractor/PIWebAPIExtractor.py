##################################################################
### PI Web API Extractor
##################################################################

### Imports
##################################################################

# Generic imports
import json
import datetime as dt
import math
# import pytz
import pandas as pd
import time
import ast
import time
import pdb
import re
import traceback
import requests
import os
from zoneinfo import ZoneInfo

import urllib3
urllib3.disable_warnings()

from requests.auth import HTTPBasicAuth

# Own imports
from AssetDataReader.extractor.PIDataExtractor import PIDataExtractor

from AssetDataReader.config.Config import ConnectionErrorAttemps
from AssetDataReader.config.Config import PiWebAPIConfig

from osisoft.pidevclub.piwebapi.pi_web_api_client import PIWebApiClient
from osisoft.pidevclub.piwebapi.rest import ApiException

from AssetDataReader.util.exceptions import ExceptionErrorCodes
from AssetDataReader.util.exceptions import DataReaderError

class PIWebAPIExtractor(PIDataExtractor):
    """ Atlantica Sustainable Infraestructure (ASI) PI Web API Extractor

    This class serves as a extractor from PI Web API server.
    """

    def __init__(self,asset_definition,piaf_user,piaf_pwd,piaf_credential_file):
        """ Class constructor

        param asset_definition: asset definition for creating
        """

        if asset_definition['type'] != 'pi_api':
            error_msg = "%s Asset type not correspond with class." % (ExceptionErrorCodes["invalid_asset"])
            raise DataReaderError(error_msg)
            
        else:

            # Get data from definition
            self.__server_endpoint = asset_definition['server_endpoint']
            self.__pi_data_server = asset_definition['pi_data_server']
            self.__pi_af_server = asset_definition['pi_af_server']
            self.__pi_af_database = asset_definition['pi_af_database']
            self.__time_zone = self._convert_tz_to_pitz(asset_definition['time_zone'])
            self.__time_zone_pytz = asset_definition['time_zone']

            # Get credentials
            if (piaf_user != None) and (piaf_pwd != None):
                credentials = {"user":piaf_user,"pwd":piaf_pwd}
            elif not ((piaf_user == None) and (piaf_pwd == None)):
                error_msg = "%s both piaf_user and piaf_pwd must be passed." % (ExceptionErrorCodes["pi_webapi_credential"])
                raise DataReaderError(error_msg)
            elif piaf_credential_file != None:
                try:
                    with open(piaf_credential_file,"r") as f:
                        credentials = json.loads(f.read())
                except Exception:
                    error_msg = "%s Credential File not found." % (ExceptionErrorCodes["pi_webapi_credential"])
                    raise DataReaderError(error_msg)
            else:
                try:
                    with open("credential.json","r") as f:
                        credentials = json.loads(f.read())
                except Exception:
                    error_msg = "%s Default Credential File not found, and no user, pwd or other Credential File passed." % (ExceptionErrorCodes["pi_webapi_credential"])
                    raise DataReaderError(error_msg)


            self.__auth = (credentials['user'],credentials['pwd'])

            # Create Client
            self.__client = PIWebApiClient(self.__server_endpoint,
                useKerberos=False,
                username=credentials['user'],
                password=credentials['pwd'],
                verifySsl=True)


    def __make_dates_bacthes(self,date_list,interval,date_from,date_to):
        """ generate date batches for a date list

        param date_list: target list with dates.
        param interval: number of days per batch.
        param date_from: start date
        param date_to: end date

        return list of date bacthes (each batch is a date list)
        """
        if interval > 1:
            i = 0
            dates_batches = []
            while i < len(date_list):
                next_i = min(i + interval,len(date_list))
                dates_batches.append(date_list[i:next_i])
                if dates_batches[-1][-1] != date_to:
                    dates_batches[-1][-1] = dates_batches[-1][-1].replace(hour=23,minute=59,second=59)
                elif len(dates_batches[-1]) == 1:
                    dates_batches[-1] = [dates_batches[-1][0].replace(hour=0,minute=0,second=0),dates_batches[-1][0]]
                i = next_i
            
            return dates_batches
        else:
            if date_from.date() == date_to.date():
                dates_batches = [[date_from,date_to]]
            else:
                dates_batches = [[x.replace(hour=0,minute=0,second=0),x.replace(hour=23,minute=59,second=59)] for x in date_list]
                dates_batches[0][0] = date_from
                dates_batches[-1][-1] = date_to

            return dates_batches


    def  __check_optimizer(self,tag_list,date_from,date_to,time_interval,tag_batches,dates_batches):
        """ Check if Optimizer works correctly. (FOR DEBUG ONLY)

        para tag_list: target tags to download.
        param date_from: start date.
        param date_to: end date.
        param time_interval: time interval in PI format.
        param tag_batches: Optimizer generated tag batches,
        param dates_batches: Optimizer generated dates batches,
        """

        is_ok = True

        # Check tag batches
        batch_to_list = []
        for item in tag_batches:
            batch_to_list += item
        

        if len(batch_to_list) != len(tag_list):
            print("[BAD] Tag lists do not match")
            is_ok = False
        
        # Check date batches
        total_seconds_dates = (date_to-date_from).total_seconds()
        total_seconds_batches = 0
        for item in dates_batches:
            total_seconds_batches += ((item[-1]-item[0]).total_seconds() + 1)
        
        total_seconds_batches -= 1

        if total_seconds_batches != total_seconds_dates:
            print("[BAD] Date batches not correct")
            is_ok = False
        

        if is_ok:
            print("Batches OK")

    def __optimize_batch_multiple(self,download_mode,tag_list,date_from,date_to,time_interval):
        """ Optimize target request according to batch configuration

        param download_mode: download flag to download recorded or interpolated values.
        param tag_list: tag list in PI Data Archive or PI AF format.
        param date_from: datetime to get data from.
        param date_to: datetime to get data to.
        param time_interval: time frequency in PI Format.

        return tag batches list and date batches list.
        """

        # Get Date range
        if (date_to-date_from).days > 0:
            date_list = self._get_date_range_list(date_from,date_to)
        else:
            date_list = [date_from,date_to]


        # Get metrics
        seconds_per_item = self._get_seconds_per_item(time_interval)
        # Total seconds to download in each batch
        total_seconds = min((date_to-date_from).total_seconds(),PiWebAPIConfig['batcher']['max_days']*24*3600)

        
        # if total_seconds <= 0:
        #     total_seconds = 1

        if date_to != date_from:

            total_items_period_tag = total_seconds / seconds_per_item

            # Get max tags per full period
            target_tags_number = int(PiWebAPIConfig['batcher']['max_items']/(total_items_period_tag))
            tags_period = min(PiWebAPIConfig['batcher']['max_tags'],target_tags_number)
        
        else: # Just for extact period of time
            tags_period = 10

        # Define predefined batches
        tag_batches = [[x] for x in tag_list]
        dates_batches = [[x] for x in date_list]


        # For calculated data are not available multiple tag donwloads
        if download_mode == "calculated":
            tags_period = 1

        # Check tag limit
        if tags_period > 1: # More than one tag can be downloaded each time for full period    

            # Generate tag batch
            i = 0
            tag_batches = []
            while i < len(tag_list):
                next_i = min(i + tags_period,len(tag_list))
                tag_batches.append(tag_list[i:next_i])
                i = next_i
            
            # Check date limit not exceed Max
            if len(date_list) > PiWebAPIConfig['batcher']['max_days']: # Generate batch for max days
                # print("[A]") # DEBUG ONLY
                dates_batches = self.__make_dates_bacthes(date_list,PiWebAPIConfig['batcher']['max_days'],date_from,date_to)
                return tag_batches,dates_batches
                
            else: # Return batched tag list for full period
                # print("[B]") # DEBUG ONLY
                return tag_batches,[date_list]

        else: # Just one tag can be downloaded per batch
            # print("[C]") # DEBUG ONLY
            # Generate dates batch
            
            target_days_number = min(int(PiWebAPIConfig['batcher']['max_items']/((60*60*24)/seconds_per_item)),PiWebAPIConfig['batcher']['max_days'])
            dates_batches = self.__make_dates_bacthes(date_list,target_days_number,date_from,date_to)        

            return tag_batches,dates_batches


    def __make_dates_bacthes_range_download(self,date_list,date_from,date_to):
        """
        """

        # Get Start and End Hour
        start_range = [date_from.hour,date_from.minute,date_from.second]
        end_range = [date_to.hour,date_to.minute,date_to.second]

        # Generate Date range
        return [[x.replace(hour=start_range[0],minute=start_range[1],second=start_range[2]),x.replace(hour=end_range[0],minute=end_range[1],second=end_range[2])] for x in date_list]


    def __optimize_batch_multiple_range_download(self,download_mode,tag_list,date_from,date_to,time_interval):
        """
        """

        # Get Date List
        if (date_to-date_from).days > 0:
            date_list = self._get_date_range_list(date_from,date_to)
        else:
            date_list = [date_from,date_to]

        # Get date batches
        dates_batches = self.__make_dates_bacthes_range_download(date_list,date_from,date_to)

        # Define predefined batches
        tag_batches = [[x] for x in tag_list]

        # Get metrics
        seconds_per_item = self._get_seconds_per_item(time_interval)
        total_seconds = (dates_batches[0][1]-dates_batches[0][0]).total_seconds()
        total_items_period_tag = total_seconds / seconds_per_item
        target_tags_number = int(PiWebAPIConfig['batcher']['max_items']/(total_items_period_tag))
        tags_period = min(PiWebAPIConfig['batcher']['max_tags'],target_tags_number)

        if tags_period > 1:
            # Generate tag batch
            i = 0
            tag_batches = []
            while i < len(tag_list):
                next_i = min(i + tags_period,len(tag_list))
                tag_batches.append(tag_list[i:next_i])
                i = next_i
        
        return tag_batches,dates_batches

    def __convert_multiple_df_uom(self,multiple_df,tags_items,items,descriptor_items):
        """
        """

        df_target = None
        # For each tag
        for i in range(len(tags_items)):
            columns = ['UnitsAbbreviation%d'%(i+1),'Timestamp%d'%(i+1)]
            df_tag = multiple_df[columns].copy()

            value_column = 'UnitsAbbreviation%d'%(i+1)
            time_column = 'Timestamp%d'%(i+1)

            # Process and prepare data
            # try:
            df_tag.loc[:,value_column] = df_tag[value_column].apply(self._current_get)
            # except Exception as e:
            #     pass

            if str(descriptor_items[i]) != "":
                tag_header = str(descriptor_items[i]) + "|" + items[i].split('\\')[-1]
            else:
                tag_header = items[i].split('\\')[-1]

            # tag_header = descriptor_items[i] + "|" + tags_items[i].replace(' ','_').replace("\\","#")

            df_tag = df_tag.copy()
            df_tag.loc[:,'tag'] = str(tag_header)
            df_tag.loc[:,'time'] = df_tag[time_column]
            df_tag.loc[:,'value'] = df_tag[value_column]


            df_tag = df_tag[['tag','time','value']]
            df_tag = df_tag.sort_values(by='time')
            df_tag = df_tag.iloc[[0],:]
            if type(df_target) != pd.DataFrame:
                df_target = df_tag
            else:
                # df_target = df_target.append(df_tag,ignore_index=True)
                df_target = pd.concat([df_target,df_tag],ignore_index=True)

        return df_target

    def __convert_multiple_df(self,download_mode,multiple_df,tags_items,items,descriptor_items,include_units):
        """ Convert multiple dataframe output to single

        param multiple_df: dataframe output from get multiple method
        param tags_items: list of target tags/paths
        param descriptor_items: list of target descriptos for each tags

        return single output dataframe
        """

        df_target = None
        
        if download_mode == 'interpolated':
            # For each tag
            for i in range(len(tags_items)):
                columns = ['Value%d'%(i+1),'Timestamp%d'%(i+1)]
                df_tag = multiple_df[columns].copy()

                value_column = 'Value%d'%(i+1)
                time_column = 'Timestamp%d'%(i+1)

                # Prepare tag
                if str(descriptor_items[i]) != ""  and descriptor_items[i] is not None:
                    tag_header = str(descriptor_items[i]) + "|" + items[i].split('\\')[-1]
                else:
                    tag_header = items[i].split('\\')[-1]

                # Get unit if needed
                if include_units:
                    unit_column = 'UnitsAbbreviation%d'%(i+1)
                    try:
                        unit = multiple_df.loc[~multiple_df[unit_column].isna(),unit_column].values[0]
                    except:
                        unit = "none"
                    
                    tag_header += "|%s" % (unit)

                # Process and prepare data
                # try:
                df_tag.loc[:,value_column] = df_tag[value_column].apply(self._current_get)
                # except Exception as e:
                #     pass

               
                # tag_header = descriptor_items[i] + "|" + tags_items[i].replace(' ','_').replace("\\","#")

                df_tag = df_tag.copy()
                df_tag.loc[:,'tag'] = str(tag_header)
                df_tag.loc[:,'time'] = df_tag[time_column]
                df_tag.loc[:,'value'] = df_tag[value_column]


                df_tag = df_tag[['tag','time','value']]
                df_tag = df_tag.sort_values(by='time')

                if type(df_target) != pd.DataFrame:
                    df_target = df_tag
                else:
                    # df_target = df_target.append(df_tag,ignore_index=True)
                    df_target = pd.concat([df_target, df_tag],ignore_index=True)

            return df_target
        else:

            # For each tag
            for i in range(len(tags_items)):
                columns = ['Value','Timestamp']
                df_tag = multiple_df[tags_items[i]][columns]

                value_column = 'Value'
                time_column = 'Timestamp'

                # Prepare tag
                if descriptor_items[i] != "" and descriptor_items[i] is not None:
                    tag_header = descriptor_items[i] + "|" + items[i].split('\\')[-1]
                else:
                    tag_header = items[i].split('\\')[-1]
                
                # Get unit if needed
                if include_units:
                    
                    unit_column = 'UnitsAbbreviation'
                    try:
                        unit = multiple_df[tags_items[i]].loc[~multiple_df[tags_items[i]][unit_column].isna(),unit_column].values[0]
                    except:
                        unit = "none"
                    
                    tag_header += "|%s" % (unit)

                # Process and prepare data
                # try:
                df_tag = df_tag.copy()
                df_tag[value_column] = df_tag[value_column].apply(self._current_get)
                # except Exception as e:
                #     pass

                
                # tag_header = descriptor_items[i] + "|" + tags_items[i].replace(' ','_').replace("\\","#")

                df_tag = df_tag.copy()
                df_tag['tag'] = str(tag_header)
                df_tag['time'] = pd.to_datetime(df_tag[time_column])
                df_tag['value'] = df_tag[value_column]
                df_tag = df_tag[['tag','time','value']]
                df_tag = df_tag.sort_values(by='time')

                if type(df_target) != pd.DataFrame:
                    df_target = df_tag
                else:
                    # df_target = df_target.append(df_tag,ignore_index=True)
                    df_target = pd.concat([df_target, df_tag],ignore_index=True)
            
            return df_target

    def __convert_calculated_df(self,df_tag,tags_items,descriptor_items,include_units):
        """
        """

        df_merged = pd.DataFrame()
        for i in range(len(tags_items)):
            descriptor = descriptor_items[i]
            item = tags_items[i]
            aux_items = item.split('\\')
            if aux_items[0] == 'af:':
                item = "_".join(aux_items[4:])
            else:
                item = item.split('\\')[-1].replace("|","_")
            

            # try:
            df_tag[tags_items[i]]['Value'] = df_tag[tags_items[i]]['Value'].apply(self._current_get)
            # except Exception as e:
            #     # print(e)
            #     pass
            
            if descriptor != "" and descriptor is not None:
                tag_header = descriptor + "|" + item
            else:
                tag_header = item

            if include_units:  
                unit_column = 'UnitsAbbreviation'
                try:
                    unit = df_tag[tags_items[i]].loc[~df_tag[tags_items[i]][unit_column].isna(),unit_column].values[0]
                except:
                    unit = "none"
                
                tag_header += "|%s" % (unit)
                
            df_tag[tags_items[i]]['tag'] = str(tag_header)
            df_tag[tags_items[i]]['time'] = pd.to_datetime(df_tag[tags_items[i]]['Timestamp'])
            df_tag[tags_items[i]]['value'] = df_tag[tags_items[i]]['Value']
            df_tag[tags_items[i]] = df_tag[tags_items[i]][['tag','time','value']]
            df_tag[tags_items[i]] = df_tag[tags_items[i]].sort_values(by='time')
            # df_merged = df_merged.append(df_tag[tags_items[i]],ignore_index=True)
            df_merged = pd.concat([df_merged, df_tag[tags_items[i]]], ignore_index=True)

        return df_merged


    def __get_tag_values_multiple(self,download_mode,tags,start_time,end_time,interval,filter_expression,include_units,calculation,calculation_time_tag,calculation_basis,on_error_continue,verbose):
        """ Get recorded target tag values for date range

        param download_mode: download flag to download recorded or interpolated values.
        param tags: target PI tag/path list.
        param start_time: date from for extracting data.
        param end_time: date to for extracting data.
        interval: time frequency in PI format.
        param calculation (default None): calculation Osisoft type if needed.
        param calculation_time_tag (default None): calculation Osisoft time type to download.
        param on_error_continue: flag to indicate if return results when a batch fails.

        return pandas dataframe with target data for batch.
        """


        # print(PiWebAPIConfig['batcher']['max_items'])

        

        tags_items = [x[0] for x in tags]
        descriptor_items = [x[1] for x in tags]

        # print(len(tags_items))

        items = []
        for tag in tags_items:
            aux_items = tag.split('\\')
            if aux_items[0] == 'af:':
                items.append("_".join(aux_items[4:]))
            else:
                items.append(tag.split('\\')[-1].replace("|","_"))
            
            #items.append((aux_tag.replace(' ','_').replace("\\","#")))
        # Remove TZ Info
        start_time = start_time.replace(tzinfo=None)
        end_time = end_time.replace(tzinfo=None)
  
        # Get data
        if download_mode == 'interpolated':
            df_tag = self.__client.data.get_multiple_interpolated_values (
                        paths=tags_items,
                        end_time = start_time,
                        start_time = end_time,
                        interval = interval,
                        filter_expression = filter_expression,
                        time_zone=self.__time_zone)

        elif download_mode == 'recorded':
            
            df_tag = self.__client.data.get_multiple_recorded_values(
                paths=tags_items,
                end_time=start_time,
                start_time=end_time,
                filter_expression = filter_expression,
                time_zone=self.__time_zone,
                # boundary_type="Interpolated",
                max_count = int(PiWebAPIConfig['batcher']['max_count']/len(tags)))

        elif download_mode == 'calculated':
            df_tag = {}
            for tag in tags_items:
                df_tag_item = self.__client.data.get_summary_values (
                    path=tag,
                    calculation_basis=calculation_basis,
                    end_time = end_time,
                    summary_type=[calculation],
                    start_time = start_time,
                    time_type=calculation_time_tag,
                    summary_duration = interval,
                    filter_expression = filter_expression,
                    time_zone=self.__time_zone
                )
                df_tag[tag] = df_tag_item
        
        elif download_mode == 'uom':

            df_tag = self.__client.data.get_multiple_interpolated_values (
                        paths=tags_items,
                        end_time = start_time,
                        start_time = end_time,
                        interval = interval,
                        filter_expression = filter_expression,
                        time_zone=self.__time_zone)


        # ## LOG FILE
        if verbose >= 4:
            df_tag.to_csv(f"data_reader_logs/call/raw_df_returned_{time.time()}.csv",index=False,header =True)

        if download_mode in ['interpolated','recorded']:
            target_df = self.__convert_multiple_df(download_mode,df_tag,tags_items,items,descriptor_items,include_units)
        
        # elif download_mode == "uom":
        #     target_df = self.__convert_multiple_df_uom(df_tag,tags_items,items,descriptor_items)

        else: # Change cause calculated values are not avaialabe for multiple downloads.
            # Process and prepare data
            # target_df = df_tag
            target_df = self.__convert_calculated_df(df_tag,tags_items,descriptor_items,include_units)

        # ## LOG FILE
        if verbose >= 4:
            target_df.to_csv(f"data_reader_logs/call/raw_conv_multiple_returned_{time.time()}.csv",index=False,header =True)

        return target_df


    def __read_values_multiple(self,download_mode,date_from,date_to,tag_list,time_interval=None,time_range_download=None,filter_expression=None,mode='long',include_units=False,calculation=None,calculation_time_tag=None,calculation_basis="TimeWeighted",verbose=False,on_error_continue=False,on_error_attemps=10):
        """ Read values from PI Web API Server

        param download_mode: download flag to download recorded or interpolated values.
        param date_from: datetime to get data from.
        param date_to: datetime to get data to.
        param tag_list: tag list in PI Data Archive or PI AF format.
        param time_interval: time frequency in PI Format.
        param calculation (default None): calculation Osisoft type if needed.
        param calculation_time_tag (default None): calculation Osisoft time type to download.
        param filter_expression: (default None) filter expression for PI Data Servers.
        param mode: dataframe structure (long/wide).
        param verbose: flag to indicate if verbosing output.
        param on_error_continue: flag to indicate if return results when a batch fails.

        return pandas dataframe with target data.
        """

        # Check PIDA or PIAF
        pi_server_type = self._get_pi_server_type(tag_list[0]['tag'])

        # Check for just instant value
        just_1_value = False
        if date_from == date_to:
            just_1_value = True
            date_to += dt.timedelta(minutes=1)

        # Get date batches
        if time_range_download == "memory_saving":
            batches = self.__optimize_batch_multiple_range_download(download_mode,tag_list,date_from,date_to,time_interval)
        else:
            batches = self.__optimize_batch_multiple(download_mode,tag_list,date_from,date_to,time_interval)

        # DEBUG ONLY
        # self.__check_optimizer(tag_list,date_from,date_to,time_interval,batches[0],batches[1])
        

        total_batches = len(batches[0]) * len(batches[1])
        if verbose == True or verbose >= 1:
            print("-------------------------------")
            print("Total tag batches: %d" % (len(batches[0])))
            print("Total date batches: %d" % (len(batches[1])))
            print("Total batches to download: %d" % (total_batches))
            print("-------------------------------")
        

        df_data = None
        # Get data
        batches_downloaded = 0
        tag_id = 0


        error_500_split_count = 0
        for batch_tag in batches[0]:
            
            # Error Flags
            error_500_flag = False
            error_500_splited_flag = False

            # Prepare tags according to PI server
            if pi_server_type == 'da':
                base_path = 'pi:\\\\%s\\' % (self.__pi_data_server)
                replaced_server = f"\\\\{self.__pi_data_server}"
            else:
                base_path = "af:\\\\%s\\%s" % (self.__pi_af_server,self.__pi_af_database)
                replaced_server = f"\\\\{self.__pi_af_server}\\{self.__pi_af_database}"

            tag_paths = []
            for tag in batch_tag:
                tag_paths.append((base_path+tag['tag'].replace(replaced_server,""),tag['descriptor']))
            


            date_id = 0
            # Get dates batch
            for idx, batch in enumerate(batches[1]):
                
                if verbose >= 3:
                    with open("verbose_output/tag_batches.txt","a") as f:
                        to_write = f"[{tag_id}::{date_id}] ({batch[0].strftime('%Y-%m-%dT%H:%M:%S')} -> {batch[-1].strftime('%Y-%m-%dT%H:%M:%S')}) --------------\n{str(batch_tag)}\n-----------------------------------\n"
                        f.write(to_write)

                start_time = time.time()

                # Get date limits for batch download
                # dt_from = dt.datetime(batch[0].year, batch[0].month, batch[0].day, batch[0].hour, batch[0].minute, batch[0].second, tzinfo=pytz.utc)
                # dt_to = dt.datetime(batch[-1].year, batch[-1].month, batch[-1].day, batch[-1].hour, batch[-1].minute, batch[-1].second, tzinfo=pytz.utc)
                dt_from = dt.datetime(batch[0].year, batch[0].month, batch[0].day, batch[0].hour, batch[0].minute, batch[0].second, tzinfo=ZoneInfo("UTC"))
                dt_to = dt.datetime(batch[-1].year, batch[-1].month, batch[-1].day, batch[-1].hour, batch[-1].minute, batch[-1].second, tzinfo=ZoneInfo("UTC"))
                

                # Extract data
                downloaded = False if not error_500_flag else True
                attemp = 0
                # max_attemps = ConnectionErrorAttemps['max_attemps']
                max_attemps = on_error_attemps
 
                while not downloaded and attemp < max_attemps:
                    
                    try:
                        
                        # if type(df_data) != pd.DataFrame:
                        #     df_data = self.__get_tag_values_multiple(download_mode,tag_paths,dt_from,dt_to,time_interval,filter_expression,include_units,calculation,calculation_time_tag,on_error_continue,verbose)
                        # else:
                        #     df_data = df_data.append(self.__get_tag_values_multiple(download_mode,tag_paths,dt_from,dt_to,time_interval,filter_expression,include_units,calculation,calculation_time_tag,on_error_continue,verbose),ignore_index=True)
                        
                        df_download_aux = self.__get_tag_values_multiple(download_mode,tag_paths,dt_from,dt_to,time_interval,filter_expression,include_units,calculation,calculation_time_tag,calculation_basis,on_error_continue,verbose)
                        if type(df_data) != pd.DataFrame:
                            df_data = df_download_aux
                        else:
                            # df_data = df_data.append(df_download_aux,ignore_index=True)
                            df_data = pd.concat([df_data, df_download_aux], ignore_index=True)
                        
                        
                        if verbose >=3:
                            os.makedirs("verbose_output",exist_ok = True)
                            df_download_aux.to_csv(f"verbose_output/{tag_id}_{date_id}.csv",index=False,header=True)

                        downloaded = True

                        date_id += 1
                        
                    
                    except Exception as e:
                        
                        # ## LOG FILE
                        if verbose >= 4:
                            trace = traceback.format_exc()
                            with open(f"data_reader_logs/call/general_read_exception_{time.time()}.txt","w") as f:
                                f.write(f"[Exception] {e}")
                                f.write("\n\n[Traceback]=================================\n\n")
                                f.write(trace)
                        # ## End LOG FILE

                        if (type(e) == DataReaderError) and (not on_error_continue):
                            raise e

                        # elif str(e) == "The returned data is Null or None" and on_error_continue:
                        #     downloaded = True

                        elif type(e) == ApiException:
                            

                            if e.status == 401:
                                error_msg = "%s Credentials are not valid. Pi Web API returns: Unauthorized (401)" % (ExceptionErrorCodes["pi_webapi_credential"])
                                
                                raise DataReaderError(error_msg)

                            elif not on_error_continue:
                                error_msg = f"\n\n{ExceptionErrorCodes['pi_webapi_error']} Reason: {e.reason} ({e.status})\n"
                                error_msg += f"(DATA READER BATCH)\n-------------------------------------\n"
                                error_msg += f"Date from: {dt_from.strftime('%Y-%m-%dT%H:%M:%S')} -> Date to: {dt_to.strftime('%Y-%m-%dT%H:%M:%S')}\n"
                                error_msg += f"Items:\n"
                                for tag_item_exception in tag_paths:
                                    error_msg += f"-> {tag_item_exception[0]}\n"

                                error_msg += f"\n(PI Web API Call)\n-------------------------------------\nURL: {e.request_definition['url']}"
                                if "payload" in e.request_definition.keys():
                                    error_msg += f"PAYLOAD:\n{e.request_definition['payload']}\n"

                                error_msg += "\n(ERROR LIST)\n-------------------------------------\n"
                                errors = json.loads(e.body)
                                for index, error in enumerate(errors['Errors']):
                                    error_msg += "[%d] %s\n" % (index+1,error)
                            

                                raise DataReaderError(error_msg)
                            
                            elif e.status == 404:

                                # Process not found
                                # dt_from_local = pytz.timezone(self.__time_zone_pytz).localize(dt_from.replace(tzinfo=None))
                                # dt_from_utc = dt_from_local.astimezone(pytz.timezone("UTC"))
                                #TOFIX
                                dt_from_local = dt_from.replace(tzinfo=None).replace( tzinfo=ZoneInfo(self.__time_zone_pytz))
                                dt_from_utc = dt_from_local.astimezone(ZoneInfo("UTC"))
                                try: # Case server return not found list
                                    # Get not founds
                                    if pi_server_type == 'da':
                                        not_found_list = [re.search("'(.*)'", x).group(1).split("\\")[-1] for x in json.loads(e.body)['Errors']]
                                        # Remove from batch tags
                                        not_found_tag = list(filter(lambda x: x['tag'] in not_found_list,batch_tag))
                                        batch_tag =  list(filter(lambda x: x['tag'] not in not_found_list,batch_tag))
                                        tag_paths = [(base_path+tag['tag'],tag['descriptor']) for tag in batch_tag]
                                        not_found_dict = [{"time":dt_from_utc,"tag":"%s|%s" % (x['descriptor'],x['tag']),"value":"not found"} for x in not_found_tag]
                                    
                                    else:
                                        not_found_list = ["af:%s" %(re.search("'(.*)'", x.split(".")[0]).group(1)) for x in json.loads(e.body)['Errors']]
                                        not_found_tag = list(filter(lambda x: x[0] in not_found_list,tag_paths))
                                        tag_paths = list(filter(lambda x: x[0] not in not_found_list,tag_paths))
                                        not_found_dict = [{"time":dt_from_utc,"tag":"%s|%s" % (x[1],"\\".join(x[0].split("\\")[4:]).replace("\\","_")),"value":"not found"} for x in not_found_tag]

                                    
                                    if type(df_data) != pd.DataFrame:
                                        df_data = pd.DataFrame.from_dict(not_found_dict)
                                    else:
                                        # df_data = df_data.append(pd.DataFrame.from_dict(not_found_dict),ignore_index=True)
                                        df_data = pd.concat([df_data, pd.DataFrame.from_dict(not_found_dict)],ignore_index=True)

                                    if len(tag_paths) <= 0:
                                        downloaded = True
                                except: # Case server does not return not found list
                                    downloaded = True
                                    error_msg = "====================================================================="
                                    error_msg += f"\n\n[ON ERROR CONTINUES WARNING] Batch will not be downloaded: {ExceptionErrorCodes['pi_webapi_error']} Reason: {e.reason} ({e.status})\n"
                                    error_msg += f"(DATA READER BATCH)\n-------------------------------------\n"
                                    error_msg += f"Date from: {dt_from.strftime('%Y-%m-%dT%H:%M:%S')} -> Date to: {dt_to.strftime('%Y-%m-%dT%H:%M:%S')}\n"
                                    error_msg += f"Items:\n"
                                    for tag_item_exception in tag_paths:
                                        error_msg += f"-> {tag_item_exception[0]}\n"

                                    error_msg += f"\n(PI Web API Call)\n-------------------------------------\nURL: {e.request_definition['url']}"
                                    if "payload" in e.request_definition.keys():
                                        error_msg += f"PAYLOAD:\n{e.request_definition['payload']}\n"

                                    error_msg += "\n(ERROR LIST)\n-------------------------------------\n"
                                    errors = json.loads(e.body)
                                    for index, error in enumerate(errors['Errors']):
                                        error_msg += "[%d] %s\n" % (index+1,error)

                                    error_msg += "\n====================================================================="
                                    print(error_msg)
                                        
                            
                            else:
                                attemp += 1

                        # Normally ERROR 500 returned from API 
                        elif str(e) == "The returned data is Null or None":
                            

                            # At least two tags to download. Split in one batch per tag
                            if len(batch_tag) > 1:
                                error_500_flag = True
                                error_500_splited_flag = True
                                for tag in batch_tag:
                                    batches[0].append([tag])

                                error_500_split_count += 1
                                total_batches = (len(batches[0])-error_500_split_count) * len(batches[1])
                                batches_downloaded = tag_id * len(batches[1])
                                downloaded = True

                                if verbose >= 1:
                                    print("-------------------------------")
                                    print("[WARNING] Error 500 from WEB API.")
                                    print("Tag Batch will be split for future download.")
                                    print(f"New total tag batches: {len(batches[0])-error_500_split_count}")
                                    print(f"New total batches: {total_batches}")
                                    print("-------------------------------")
                           
                            # Just 1 tag, go to next batch
                            else:
                                if on_error_continue:
                                    downloaded = True
                                    # attemp += max_attemps
                                else:
                                    raise e
                        
                        elif str(e) == "Bad error processing by Osisoft Python Client":
                            raise e

                        else:
                            if attemp >= (max_attemps-1):
                                if on_error_continue:
                                    attemp += 1
                                else:
                                    error_msg = "%s Max attemps exceeded when downloading data." % (ExceptionErrorCodes["read_error"])
                                    raise DataReaderError(error_msg)
                            else:
                                attemp += 1
                                time.sleep(ConnectionErrorAttemps['time_to_sleep'])

                if verbose == True or verbose >= 1 and not error_500_splited_flag:
                    batches_downloaded += 1
                    print("[%d/%d] %s" % (batches_downloaded,total_batches,self.pretty_time(time.time()-start_time)))

            tag_id += 1
        if verbose == True or verbose >= 1:
            print("-------------------------------")


        # Keep just instant time for one value download
        if just_1_value:
            # date_from_utc = pytz.timezone(self.__time_zone_pytz).localize(date_from).astimezone(pytz.timezone("UTC"))
            date_from_utc = date_from.replace(tzinfo=ZoneInfo(self.__time_zone_pytz)).astimezone(ZoneInfo("UTC"))
            df_data = df_data.loc[df_data['time'].str[:-1] == date_from_utc.strftime("%Y-%m-%dT%H:%M:%S"),:]



        # Replace Microseconds component
        if type(df_data) == pd.DataFrame:
            df_data.drop(index=df_data.loc[df_data['time'].isna()].index,inplace=True)
            df_data['time'] = df_data['time'].values.astype('datetime64[s]')
            # df_data['time'] = pd.to_datetime(df_data['time'],errors="coerce")
            # data['from_timestamp']=data['from_timestamp'].values.astype('datetime64[s]')

            # For just a value remove API Duplicates
            df_data.drop_duplicates(['time','tag'],keep= 'first',inplace=True)
            # Pivot pandas dataframe if wide mode
            if mode == "wide":
                if download_mode == 'recorded' or (download_mode == "calculated" and calculation_time_tag == 'Auto'):
                    
                    df_wide = pd.DataFrame()
                    for name,group in df_data.groupby("tag"):
                        group.drop(["tag"],axis=1,inplace=True)
                        group.rename(columns={"time":"time|%s"%(name),"value":name},inplace=True)
                        group.reset_index(inplace=True)
                        df_wide = pd.concat([df_wide,group],axis=1,join="outer")
                        df_wide.drop(columns=['index'],inplace=True)

                    df_data = df_wide

                else:
                    #df_data = pd.pivot_table(df_data,values='value',index='time',columns = 'tag').reset_index()
                    not_nat = df_data.loc[~ pd.isnull(df_data.time)]
                    df_data.loc[pd.isnull(df_data.time),'time'] = not_nat.time.values[0]
                    df_data = df_data.pivot(values='value',index='time',columns = 'tag').reset_index()
                    # del df_data.columns.name

            return df_data

        else:
            error_msg = "%s No data returned from PI Web API." % (ExceptionErrorCodes["data_error"])
            raise DataReaderError(error_msg)


    def pretty_time(self,seconds):
        """ Format seconds in hours, minutes and seconds string format

        param seconds: total seconds
        return string with hours, minutes and seconds format
        """

        pretty_str = ""
        s_aux = seconds

        # Parse hour
        if int(s_aux/3600) != 0:
            pretty_str += "%dh " % (int(s_aux/3600))
            s_aux = s_aux % 3600
        
        if int(s_aux/60) != 0:
            pretty_str += "%dm " % (int(s_aux/60))
            s_aux = s_aux % 60
        
        pretty_str += "%ds" % (s_aux)

        return pretty_str


    def read_pipoints_from_path(self,tag_list,verbose,on_error_continue,on_error_attemps):
        """ Get Pi-Points for a given PIAF path list

        param tag_list: tag list in PI Data Archive or PI AF format.
        param verbose: flag to indicate if verbosing output.
        param on_error_continue: flag to indicate if return results when a batch fails.
        param on_error_attempts: flag to indicate how m,any attemps perform before reporting error

        """


        # Prepare tags according to PI server
        base_path = "\\\\%s\\%s" % (self.__pi_af_server,self.__pi_af_database)
        tag_paths = [(base_path+tag['tag'],tag['descriptor']) for tag in tag_list]
        

        if verbose == True or verbose >= 1:
            print("-------------------------------")
            print("Total tags to get pipoints: %d" % (len(tag_paths)))
            print("-------------------------------")

        # Get Pi Points for each tag
        df_data = pd.DataFrame()
        points_downloaded = 0
        start_time_total = time.time()
        for tag_path in tag_paths:
            start_time_point = time.time()
            try:
                # Get attribute by path
                url = f"{self.__server_endpoint}/attributes?path={tag_path[0]}"
                resp = requests.get(url,auth=self.__auth)
                if resp.status_code != 200:
                    if resp.status_code == 401:
                        error_msg = "%s Credentials are not valid. Pi Web API returns: Unauthorized (401)" % (ExceptionErrorCodes["pi_webapi_credential"])    
                        raise DataReaderError(error_msg)

                piaf_item = resp.json()

                # Get PI Point
                pipoint_item = requests.get(piaf_item['Links']['Point'],auth=self.__auth).json()


                # df_data = df_data.append(pd.DataFrame({"descriptor":[tag_path[1]],"piaf_path":[tag_path[0]],"pipoint":[pipoint_item['Name']]}),ignore_index=True)
                df_data = pd.concat([df_data, pd.DataFrame({"descriptor":[tag_path[1]],"piaf_path":[tag_path[0]],"pipoint":[pipoint_item['Name']]})], ignore_index=True)
            
                if verbose == True or verbose >= 1:
                    points_downloaded += 1
                    print("[%d/%d] %s (%s)" % (points_downloaded,len(tag_paths),self.pretty_time(time.time()-start_time_point),self.pretty_time(time.time()-start_time_total)))

            except Exception as e:

                if resp.status_code == 401:
                    error_msg = "%s Credentials are not valid. Pi Web API returns: Unauthorized (401)" % (ExceptionErrorCodes["pi_webapi_credential"])    
                    raise DataReaderError(error_msg)

                elif not on_error_continue:
                    raise e

        if verbose == True or verbose >= 1:
            print("-------------------------------")

        return df_data


    def read_descriptor_from_point(self,tag_list,verbose,on_error_continue,on_error_attemps):
        """ Get descriptor for a given tag (Pi Point) list

        param tag_list: tag list in PI Data Archive
        param verbose: flag to indicate if verbosing output.
        param on_error_continue: flag to indicate if return results when a batch fails.
        param on_error_attempts: flag to indicate how m,any attemps perform before reporting error

        """


        # Prepare tags according to PI server
        base_path = "\\\\%s\\" % (self.__pi_data_server)
        tag_paths = [(base_path+tag['tag'],tag['descriptor']) for tag in tag_list]
        

        if verbose == True or verbose >= 1:
            print("-------------------------------")
            print("Total tags to get pipoints: %d" % (len(tag_paths)))
            print("-------------------------------")

        # Get Pi Points for each tag
        df_data = pd.DataFrame()
        points_downloaded = 0
        start_time_total = time.time()
        for tag_path in tag_paths:
            start_time_point = time.time()
            try:
                # Get attribute by path
                url = f"{self.__server_endpoint}/points?path={tag_path[0]}"
                resp = requests.get(url,auth=self.__auth)
                if resp.status_code != 200:
                    if resp.status_code == 401:
                        error_msg = "%s Credentials are not valid. Pi Web API returns: Unauthorized (401)" % (ExceptionErrorCodes["pi_webapi_credential"])    
                        raise DataReaderError(error_msg)

                pipoint_item = resp.json()



                # df_data = df_data.append(pd.DataFrame({"descriptor":[tag_path[1]],"tag":[tag_path[0]],"pi_descriptor":[pipoint_item['Descriptor']]}),ignore_index=True)
                df_data = pd.concat([df_data, pd.DataFrame({"descriptor":[tag_path[1]],"tag":[tag_path[0]],"pi_descriptor":[pipoint_item['Descriptor']]})], ignore_index=True)
            
                if verbose == True or verbose >= 1:
                    points_downloaded += 1
                    print("[%d/%d] %s (%s)" % (points_downloaded,len(tag_paths),self.pretty_time(time.time()-start_time_point),self.pretty_time(time.time()-start_time_total)))

            except Exception as e:

                if resp.status_code == 401:
                    error_msg = "%s Credentials are not valid. Pi Web API returns: Unauthorized (401)" % (ExceptionErrorCodes["pi_webapi_credential"])    
                    raise DataReaderError(error_msg)

                elif not on_error_continue:
                    raise e

                


        if verbose == True or verbose >= 1:
            print("-------------------------------")

        return df_data



    def __read_last_value_multiple(self,tag_list,verbose=False,on_error_continue=False,on_error_attempts=10):
        """
        """

        # Check PIDA or PIAF
        pi_server_type = self._get_pi_server_type(tag_list[0]['tag'])

        if verbose == True or verbose >= 1:
            print("-------------------------------")
            print("Total tags to get last value: %d" % (len(tag_list)))
            print("-------------------------------")
        
        ## Get real tag names
        real_tags = []
        descriptor_mapping = {}
        for tag in tag_list:
            if pi_server_type == 'da':
                real_tags.append(f"\\\\{self.__pi_data_server}\\{tag['tag']}")
                descriptor_mapping[f"\\\\{self.__pi_data_server}\\{tag['tag']}"] = f"{tag['descriptor']}|{tag['tag']}"
            else:
                real_tags.append(f"\\\\{self.__pi_af_server}\\{self.__pi_af_database}{tag['tag']}")
                renamed_tag = tag['tag'].replace('\\','_')[1:]
                descriptor_mapping[f"\\\\{self.__pi_af_server}\\{self.__pi_af_database}{tag['tag']}"] = f"{tag['descriptor']}|{renamed_tag}"

        dict_last_update = {"tag":[],"time":[],"value":[]}
        total_downloaded = 0
        for tag in real_tags:
            start_time_tag = time.time()
            downloaded = False
            attemp = 0
            # max_attemps = ConnectionErrorAttemps['max_attemps']
            max_attemps = on_error_attempts

            while not downloaded and attemp < max_attemps:

                try:
                    if pi_server_type == 'da':
                        ## Get element
                        url = f"{self.__server_endpoint}/points"
                        path = tag
                        resp = requests.get(url,params={"path":path},auth=HTTPBasicAuth(self.__auth[0],self.__auth[1]))
                        if resp.status_code == 401:
                            error_msg = "%s Credentials are not valid. Pi Web API returns: Unauthorized (401)" % (ExceptionErrorCodes["pi_webapi_credential"])    
                            raise DataReaderError(error_msg)
                        elif resp.status_code == 404:
                            error_msg = "%s Tag Not Found: %s" % (ExceptionErrorCodes["pi_webapi_error"],tag)    
                            raise DataReaderError(error_msg)
                        elif not resp.ok:
                            error_msg = "%s PI Web API Error: %s" % (ExceptionErrorCodes["pi_webapi_error"],e)    
                            raise DataReaderError(error_msg)

                        webapi_object = resp.json()

                        ## Get last value
                        last_value_url = webapi_object['Links']['Value']
                        resp = requests.get(last_value_url,auth=HTTPBasicAuth(self.__auth[0],self.__auth[1]))
                        last_value_object = resp.json()

                        value_to_get = last_value_object['Value'] if type(last_value_object['Value']) != dict else last_value_object['Value']['Name']
                        dict_last_update['tag'].append(descriptor_mapping[tag])
                        dict_last_update['time'].append(last_value_object['Timestamp'])
                        dict_last_update['value'].append(value_to_get)
                    
                    else:
                        url = f"{self.__server_endpoint}/attributes"
                        path = tag
                        resp = requests.get(url,params={"path":path},auth=HTTPBasicAuth(self.__auth[0],self.__auth[1]))
                        if resp.status_code == 401:
                            error_msg = "%s Credentials are not valid. Pi Web API returns: Unauthorized (401)" % (ExceptionErrorCodes["pi_webapi_credential"])    
                            raise DataReaderError(error_msg)
                        elif resp.status_code == 404:
                            error_msg = "%s Tag Not Found: %s" % (ExceptionErrorCodes["pi_webapi_error"],tag)    
                            raise DataReaderError(error_msg)
                        elif not resp.ok:
                            error_msg = "%s PI Web API Error: %s" % (ExceptionErrorCodes["pi_webapi_error"],e)    
                            raise DataReaderError(error_msg)
                    
                        webapi_object = resp.json()

                        ## Get last value
                        last_value_url = webapi_object['Links']['Value']
                        resp = requests.get(last_value_url,auth=HTTPBasicAuth(self.__auth[0],self.__auth[1]))
                        if not resp.ok:
                            error_msg = "%s PI Web API Error: %s" % (ExceptionErrorCodes["pi_webapi_error"],e)    
                            raise DataReaderError(error_msg)
                        last_value_object = resp.json()

                        value_to_get = last_value_object['Value'] if type(last_value_object['Value']) != dict else last_value_object['Value']['Name']
                        dict_last_update['tag'].append(descriptor_mapping[tag])
                        dict_last_update['time'].append(last_value_object['Timestamp'])
                        dict_last_update['value'].append(value_to_get)

                    if verbose == True or verbose >= 1:
                        total_downloaded += 1
                        print(f"[{total_downloaded}/{len(real_tags)}] {self.pretty_time(time.time()-start_time_tag)}")

                    downloaded = True
                except Exception as e:
                    if not on_error_continue or attemp >= on_error_attempts:
                        raise DataReaderError(e)
                    else:
                        attemp += 1
                        time.sleep(ConnectionErrorAttemps['time_to_sleep'])


        if verbose == True or verbose >= 1:
            print("-------------------------------")

        df_data = pd.DataFrame(dict_last_update,dtype=str)
        df_data['time'] = pd.to_datetime(df_data['time'].str[:-1])

        return df_data




    ### Asset Reader Access Functions
    #########################################################################
    
    def read_recorded_values(self,date_from,date_to,tag_list,time_interval="1s",time_range_download=None,filter_expression=None,mode='long',include_units=False,verbose=False,on_error_continue=False,on_error_attemps=10):
        """ Read recorded values from PI Web API server

        Recorded values from PI Server will be always in long mode.

        param date_from: datetime to get data from.
        param date_to: datetime to get data to.
        param tag_list: tag list in PI Data Archive or PI AF format.
        param filter_expression: (default None) filter expression for PI Data Servers.
        param verbose: flag to indicate if verbosing output.
        param on_error_continue: flag to indicate if return results when a batch fails.
        
        return dataframe with requested values in long mode.
        """
        return self.__read_values_multiple('recorded',date_from,date_to,tag_list,time_interval,time_range_download,filter_expression,mode=mode,include_units=include_units,verbose=verbose,on_error_continue=on_error_continue,on_error_attemps=on_error_attemps)
    
    def read_interpolated_values(self,date_from,date_to,tag_list,time_interval,time_range_download=None,filter_expression=None,mode='long',include_units=False,verbose=False,on_error_continue=False,on_error_attemps=10):
        """ Read interpolated values from PI Web API Server

        param date_from: datetime to get data from.
        param date_to: datetime to get data to.
        param tag_list: tag list in PI Data Archive or PI AF format.
        param time_interval: time frequency in PI Format.
        param filter_expression: (default None) filter expression for PI Data Servers.
        param mode: dataframe structure (long/wide).
        param verbose: flag to indicate if verbosing output.
        param on_error_continue: flag to indicate if return results when a batch fails.

        return dataframe with requested values.
        """

        return self.__read_values_multiple('interpolated',date_from,date_to,tag_list,time_interval,time_range_download,filter_expression,mode,include_units,verbose=verbose,on_error_continue=on_error_continue,on_error_attemps=on_error_attemps)

    def read_calculated_values(self,date_from,date_to,tag_list,time_interval=None,time_range_download=None,calculation=None,calculation_time_tag=None,calculation_basis="TimeWeighted",filter_expression=None,mode='long',include_units=False,verbose=False,on_error_continue=False,on_error_attemps=10):
        """ Read calculated values from PI Web API Server

        param date_from: datetime to get data from.
        param date_to: datetime to get data to.
        param tag_list: tag list in PI Data Archive or PI AF format.
        param time_interval: time frequency in PI Format.
        param calculation (default None): calculation Osisoft type if needed.
        param calculation_time_tag (default None): calculation Osisoft time type to download.
        param filter_expression: (default None) filter expression for PI Data Servers.
        param mode: dataframe structure (long/wide).
        param verbose: flag to indicate if verbosing output.
        param on_error_continue: flag to indicate if return results when a batch fails.

        return dataframe with requested values.
        """
        
        return self.__read_values_multiple('calculated',date_from,date_to,tag_list,time_interval,time_range_download,filter_expression,mode,include_units=include_units,calculation=calculation,calculation_time_tag=calculation_time_tag,calculation_basis=calculation_basis,verbose=verbose,on_error_continue=on_error_continue,on_error_attemps=on_error_attemps)



    # def read_pipoints_from_path(self,tag_list,verbose=False,on_error_continue=False,on_error_attemps=10):
    #     """ Get Pi-Points for a given PIAF path list

    #     param tag_list: tag list in PI Data Archive or PI AF format.
    #     param verbose: flag to indicate if verbosing output.
    #     param on_error_continue: flag to indicate if return results when a batch fails.
    #     param on_error_attempts: flag to indicate how m,any attemps perform before reporting error

    #     """

    #     return self.__read_pipoints_from_path(tag_list,verbose,on_error_continue,on_error_attemps)



    def read_last_value(self,tag_list,verbose=False,on_error_continue=False,on_error_attempts=10):
        """
        """

        return self.__read_last_value_multiple(tag_list=tag_list,verbose=verbose,on_error_continue=on_error_continue,on_error_attempts=on_error_attempts)


    def read_unit_values(self,date_from,date_to,tag_list,verbose=False,on_error_continue=False,on_error_attemps=10):
        """
        """

        return self.__read_values_multiple('uom',date_from,date_to,tag_list,time_interval="1h",verbose=verbose,on_error_continue=on_error_continue)




        
        
    


