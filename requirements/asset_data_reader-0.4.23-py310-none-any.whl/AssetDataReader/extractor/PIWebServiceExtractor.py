##################################################################
### PI Web Service Extractor
##################################################################
#
# http://ayazuvpiapi01.atlanticayield.com/PIWebServices/PITimeSeries.svc
#
##################################################################


### Imports
##################################################################

# Generic imports
import json
import datetime as dt
import math
# import pytz
import pandas as pd
import requests
from lxml import etree
import time
from zoneinfo import ZoneInfo

# Own imports
from AssetDataReader.extractor.PIDataExtractor import PIDataExtractor

from AssetDataReader.config.Config import ConnectionErrorAttemps
from AssetDataReader.config.Config import PiWebServiceConfig

from AssetDataReader.util.exceptions import ExceptionErrorCodes
from AssetDataReader.util.exceptions import DataReaderError

class PIWebServiceExtractor(PIDataExtractor):
    """ Atlantica Sustainable Infraestructure (ASI) PI Web Service Extractor

    This class serves as a extractor from PI Web Service server.
    """

    def __init__(self,asset_definition):
        """ Class constructor

        param asset_definition: asset definition for creating
        """

        if asset_definition['type'] != 'pi_service':
            error_msg = "%s Asset type not correspond with class." % (ExceptionErrorCodes["invalid_asset"])
            raise DataReaderError(error_msg)
        else:

            # Get asset definition
            self.__endpoint = asset_definition['server_endpoint']
            self.__host = asset_definition['server_host']
            self.__pidataserver = asset_definition['pi_data_server']
            self.__time_zone = asset_definition['time_zone']
            self.__maximum_batch = PiWebServiceConfig['batcher']['max_items']


    def __make_dates_bacthes(self,date_list,interval,date_from,date_to):
        """ generate date batches for a date list

        param date_list: target list with dates.
        param interval: number of days per batch.
        param date_from: start date
        param date_to: end date

        return list of date bacthes (each batch is a date list)
        """
        if interval > 1:
            i = 0
            dates_batches = []
            while i < len(date_list):
                next_i = min(i + interval,len(date_list))
                dates_batches.append(date_list[i:next_i])
                if dates_batches[-1][-1] != date_to:
                    dates_batches[-1][-1] = dates_batches[-1][-1].replace(hour=23,minute=59,second=59)
                elif len(dates_batches[-1]) == 1:
                    dates_batches[-1] = [dates_batches[-1][0].replace(hour=0,minute=0,second=0),dates_batches[-1][0]]
                i = next_i
            
            return dates_batches
        else:
            if date_from.date() == date_to.date():
                dates_batches = [[date_from,date_to]]
            else:
                dates_batches = [[x.replace(hour=0,minute=0,second=0),x.replace(hour=23,minute=59,second=59)] for x in date_list]
                dates_batches[0][0] = date_from
                dates_batches[-1][-1] = date_to

            return dates_batches
    
    def __optimize_batch_size(self,date_from,date_to,time_step,tag_list):
        """ Get optimum batch size according to Max Batch Size

        param date_range: date range tuple with (date_from,date_to)
        param time_step: time frequency in PI format
        param tag_list: target tags to read
        return tag batch
        return date batch
        """
        
        # Parse dates
        if (date_to-date_from).days > 0:
            date_list = self._get_date_range_list(date_from,date_to)
        else:
            date_list = [date_from,date_to]


        # Get total items per day
        total_per_day = (len(tag_list) * self._get_items_per_tag(time_step)) / self.__maximum_batch
        total_splits = math.ceil(total_per_day)

        # If total tags exceed one day limit
        if total_splits > 1:
            splited_list = [tag_list[i::total_splits] for i in range(total_splits)]
            return splited_list,[date_list]

        # Else
        # Check number of days for each batch
        total_items = (len(date_list) * (len(tag_list) * self._get_items_per_tag(time_step))) / self.__maximum_batch
        total_splits_day = math.ceil(total_items)
        splited_dates = []
        amount = math.ceil(len(date_list) / total_splits_day)

        splited_dates = self.__make_dates_bacthes(date_list,amount,date_from,date_to)

        return [tag_list],splited_dates

    def __optimize_batch_multiple(self,download_mode,tag_list,date_from,date_to,time_interval):
        """ Optimize target request according to batch configuration

        param download_mode: download flag to download recorded or interpolated values.
        param tag_list: tag list in PI Data Archive or PI AF format.
        param date_from: datetime to get data from.
        param date_to: datetime to get data to.
        param time_interval: time frequency in PI Format.

        return tag batches list and date batches list.
        """

        # Get Date range
        if (date_to-date_from).days > 0:
            date_list = self._get_date_range_list(date_from,date_to)
        else:
            date_list = [date_from,date_to]

        # Get metrics
        seconds_per_item = self._get_seconds_per_item(time_interval)
        # Total seconds to download in each batch
        total_seconds = min((date_to-date_from).total_seconds(),PiWebServiceConfig['batcher']['max_days']*24*3600)
        
        # if total_seconds <= 0:
        #     total_seconds = 1

        if date_to != date_from:

            total_items_period_tag = total_seconds / seconds_per_item

            # Get max tags per full period
            target_tags_number = int(PiWebServiceConfig['batcher']['max_items']/(total_items_period_tag))
            tags_period = min(PiWebServiceConfig['batcher']['max_tags'],target_tags_number)
        
        else: # Just for extact period of time
            tags_period = 10


        # Define predefined batches
        tag_batches = [[x] for x in tag_list]
        dates_batches = [[x] for x in date_list]

        # For calculated data are not available multiple tag donwloads
        if download_mode == "calculated":
            tags_period = 1

        # Check tag limit
        if tags_period > 1: # More than one tag can be downloaded each time for full period    

            # Generate tag batch
            i = 0
            tag_batches = []
            while i < len(tag_list):
                next_i = min(i + tags_period,len(tag_list))
                tag_batches.append(tag_list[i:next_i])
                i = next_i
            
            # Check date limit not exceed Max
            if len(date_list) > PiWebServiceConfig['batcher']['max_days']: # Generate batch for max days
                # print("[A]") # DEBUG ONLY
                dates_batches = self.__make_dates_bacthes(date_list,PiWebServiceConfig['batcher']['max_days'],date_from,date_to)
                return tag_batches,dates_batches
                
            else: # Return batched tag list for full period
                # print("[B]") # DEBUG ONLY
                return tag_batches,[date_list]

        
        else: # Just one tag can be downloaded per batch
            # print("[C]") # DEBUG ONLY
            # Generate dates batch
            target_days_number = min(int(PiWebServiceConfig['batcher']['max_items']/((60*60*24)/seconds_per_item)),PiWebServiceConfig['batcher']['max_days'])
            dates_batches = self.__make_dates_bacthes(date_list,target_days_number,date_from,date_to)        

            return tag_batches,dates_batches



    def __make_dates_bacthes_range_download(self,date_list,date_from,date_to):
        """
        """

        # Get Start and End Hour
        start_range = [date_from.hour,date_from.minute,date_from.second]
        end_range = [date_to.hour,date_to.minute,date_to.second]

        # Generate Date range
        return [[x.replace(hour=start_range[0],minute=start_range[1],second=start_range[2]),x.replace(hour=end_range[0],minute=end_range[1],second=end_range[2])] for x in date_list]


    def __optimize_batch_multiple_range_download(self,download_mode,tag_list,date_from,date_to,time_interval):
        """
        """

        # Get Date List
        if (date_to-date_from).days > 0:
            date_list = self._get_date_range_list(date_from,date_to)
        else:
            date_list = [date_from,date_to]

        # Get date batches
        dates_batches = self.__make_dates_bacthes_range_download(date_list,date_from,date_to)

        # Define predefined batches
        tag_batches = [[x] for x in tag_list]

        # Get metrics
        seconds_per_item = self._get_seconds_per_item(time_interval)
        total_seconds = (dates_batches[0][1]-dates_batches[0][0]).total_seconds()

        total_items_period_tag = total_seconds / seconds_per_item
        target_tags_number = int(PiWebServiceConfig['batcher']['max_items']/(total_items_period_tag))
        tags_period = min(PiWebServiceConfig['batcher']['max_tags'],target_tags_number)

        if tags_period > 1:
            # Generate tag batch
            i = 0
            tag_batches = []
            while i < len(tag_list):
                next_i = min(i + tags_period,len(tag_list))
                tag_batches.append(tag_list[i:next_i])
                i = next_i
        
        return tag_batches,dates_batches


    def __get_xml_batch_data(self,download_mode,batch_tags,batch_dates,time_step,filter_expression):
        """ Get XML Data from target batch

        param download_mode: download mode available on asset data server service
        param batch_tags: tag list of partial batch
        param batch_dates: date list of partial batch
        param time_step: time frequency in PI format
        param filter_expression: (default None) filter expression for PI Data Servers
        return xml format raw data from PI
        """

        # Prepare XML request content
        xml_content = ""

        # Start fixed content
        xml_content += '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:pid="http://xml.osisoft.com/services/PIDataService">'
        xml_content += '<soapenv:Header/>'
        xml_content += '<soapenv:Body>'
        xml_content += '<pid:GetPIArchiveData>'
        xml_content += '<pid:requests>'

        # Process time zone
        # tz_utc = pytz.timezone('UTC')
        # tz_local = pytz.timezone(self.__time_zone)
        tz_utc = ZoneInfo('UTC')
        tz_local = ZoneInfo(self.__time_zone)

        # dt_from = tz_local.localize(dt.datetime(batch_dates[0].year,batch_dates[0].month,batch_dates[0].day,batch_dates[0].hour,batch_dates[0].minute,0))#.tzinfo=pytz.timezone('UTC')
        # dt_to = tz_local.localize(dt.datetime(batch_dates[-1].year,batch_dates[-1].month,batch_dates[-1].day,batch_dates[-1].hour,batch_dates[-1].minute,59))#.tzinfo=pytz.timezone('UTC')

        dt_from = dt.datetime(batch_dates[0].year,batch_dates[0].month,batch_dates[0].day,batch_dates[0].hour,batch_dates[0].minute,0).replace(tzinfo=tz_local) #.tzinfo=pytz.timezone('UTC')
        dt_to   = dt.datetime(batch_dates[-1].year,batch_dates[-1].month,batch_dates[-1].day,batch_dates[-1].hour,batch_dates[-1].minute,59).replace(tzinfo=tz_local) #.tzinfo=pytz.timezone('UTC')

        dt_from_str = dt_from.strftime("%Y-%m-%dT%H:%M%z")
        dt_from_str = dt_from_str[:-2] + ":" + dt_from_str[-2:]
        dt_to_str = dt_to.strftime("%Y-%m-%dT%H:%M%z")
        dt_to_str = dt_to_str[:-2] + ":" + dt_to_str[-2:]


        # Add tag search contents
        for tag in batch_tags:
            xml_content += '<pid:PIArcDataRequest>'

            xml_content += '<pid:TimeRange>'
            # xml_content += '<pid:Start>%s</pid:Start>' % (batch_dates[0].strftime("%Y-%m-%dT00:00"+time_zone))#2018-03-24T02:00Z
            # xml_content += '<pid:End>%s</pid:End>' % (batch_dates[-1].strftime("%Y-%m-%dT23:59"+time_zone))#2018-03-24T02:00Z
            xml_content += '<pid:Start>%s</pid:Start>' % (dt_from_str)#2018-03-24T02:00Z
            xml_content += '<pid:End>%s</pid:End>' % (dt_to_str)#2018-03-24T02:00Z
            xml_content += '</pid:TimeRange>'

            xml_content += '<pid:Path>pi:\\\\%s\\%s</pid:Path>' % (self.__pidataserver,tag)
            
            if download_mode == 'interpolated':
                xml_content += '<pid:PIArcManner Updates="false" RetrievalType="Interpolated" NumValues="%d" Boundaries="Inside">' % self.__maximum_batch
                if filter_expression != None:
                    xml_content += ' <pid:Filter>%s</pid:Filter>'% (filter_expression)
                xml_content += '<pid:TimeStep>%s</pid:TimeStep>' % (time_step)
                xml_content += '</pid:PIArcManner>'
            elif download_mode == 'recorded':
                xml_content += '<pid:PIArcManner Updates="false" RetrievalType="Compressed" NumValues="%d" Boundaries="Inside">' % self.__maximum_batch
                if filter_expression != None:
                    xml_content += ' <pid:Filter>%s</pid:Filter>'% (filter_expression)
                xml_content += '</pid:PIArcManner>'


            xml_content += '</pid:PIArcDataRequest>'

        # End fixed content
        xml_content += '</pid:requests>'
        xml_content += '</pid:GetPIArchiveData>'
        xml_content += '</soapenv:Body>'
        xml_content += '</soapenv:Envelope>'
        
        # Do request
        headers = {
            "Content-Type":"text/xml;charset=UTF-8",
            "SOAPAction": "http://xml.osisoft.com/services/IPITimeSeries/GetPIArchiveData",
            "Host": self.__host
        }


            
        response = requests.post(self.__endpoint,headers=headers,data = xml_content)

        if response.status_code != 200:
            raise Exception("Error downloading data:\n%s" % (response.text))


        return response.text
    
    def __get_xml_batch_data_calculated(self,download_mode,batch_tags,batch_dates,time_step,calculation,filter_expression,calculation_time_tag):
        """ Get XML Summary Data from target batch

        param download_mode: download mode available on asset data server service.
        param batch_tags: tag list of partial batch
        param batch_dates: date list of partial batch
        param time_step: time frequency in PI format
        param calculation: calculation Osisoft type if needed
        param filter_expression: (default None) filter expression for PI Data Servers
        return xml format raw data from PI
        """

        # Prepare XML request content
        xml_content = ""

        # Start fixed content
        xml_content += '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:pid="http://xml.osisoft.com/services/PIDataService">'
        xml_content += '<soapenv:Header/>'
        xml_content += '<soapenv:Body>'
        xml_content += '<pid:GetPISummaryData>'
        xml_content += '<pid:requests>'

        # Process time zone
        # tz_utc = pytz.timezone('UTC')
        # tz_local = pytz.timezone(self.__time_zone)
        tz_utc = ZoneInfo('UTC')
        tz_local = ZoneInfo(self.__time_zone)

        # dt_from = tz_local.localize(dt.datetime(batch_dates[0].year,batch_dates[0].month,batch_dates[0].day,batch_dates[0].hour,batch_dates[0].minute,0))#.tzinfo=pytz.timezone('UTC')
        # dt_to = tz_local.localize(dt.datetime(batch_dates[-1].year,batch_dates[-1].month,batch_dates[-1].day,batch_dates[-1].hour,batch_dates[-1].minute,59))#.tzinfo=pytz.timezone('UTC')
        
        dt_from = dt.datetime(batch_dates[0].year,batch_dates[0].month,batch_dates[0].day,batch_dates[0].hour,batch_dates[0].minute,0).replace(tzinfo = tz_local) #.tzinfo=pytz.timezone('UTC')
        dt_to = dt.datetime(batch_dates[-1].year,batch_dates[-1].month,batch_dates[-1].day,batch_dates[-1].hour,batch_dates[-1].minute,59).replace(tzinfo=tz_local) #.tzinfo=pytz.timezone('UTC')

        dt_from_str = dt_from.strftime("%Y-%m-%dT%H:%M%z")
        dt_from_str = dt_from_str[:-2] + ":" + dt_from_str[-2:]
        dt_to_str = dt_to.strftime("%Y-%m-%dT%H:%M%z")
        dt_to_str = dt_to_str[:-2] + ":" + dt_to_str[-2:]


        # Add tag search contents
        for tag in batch_tags:
            xml_content += '<pid:PISummaryDataRequest>'

            xml_content += '<pid:TimeRange>'
            # xml_content += '<pid:Start>%s</pid:Start>' % (batch_dates[0].strftime("%Y-%m-%dT00:00"+time_zone))#2018-03-24T02:00Z
            # xml_content += '<pid:End>%s</pid:End>' % (batch_dates[-1].strftime("%Y-%m-%dT23:59"+time_zone))#2018-03-24T02:00Z
            xml_content += '<pid:Start>%s</pid:Start>' % (dt_from_str)#2018-03-24T02:00Z
            xml_content += '<pid:End>%s</pid:End>' % (dt_to_str)#2018-03-24T02:00Z
            xml_content += '</pid:TimeRange>'

            xml_content += '<pid:Path>pi:\\\\%s\\%s</pid:Path>' % (self.__pidataserver,tag)
            # <pid:PISummaryManner Updates="false" SummaryValue="Average" Intervals="1000000" WeightType="TimeWeighted" UseStart="true">
            #       <pid:TimeStep>10m</pid:TimeStep>
            # </pid:PISummaryManner>

            xml_content += '<pid:PISummaryManner Updates="false" SummaryValue="%s" Intervals="1000000" WeightType="TimeWeighted" UseStart="true">' % (calculation)
            if filter_expression != None:
                    xml_content += ' <pid:Filter>%s</pid:Filter>'% (filter_expression)
            xml_content += '<pid:TimeStep>%s</pid:TimeStep>' % (time_step)
            xml_content += '</pid:PISummaryManner>'
            xml_content += '</pid:PISummaryDataRequest>'

        # End fixed content
        xml_content += '</pid:requests>'
        xml_content += '</pid:GetPISummaryData>'
        xml_content += '</soapenv:Body>'
        xml_content += '</soapenv:Envelope>'
        
        # Do request
        headers = {
            "Content-Type":"text/xml;charset=UTF-8",
            "SOAPAction": "http://xml.osisoft.com/services/IPITimeSeries/GetPISummaryData",
            "Host": self.__host
        }



        response = requests.post(self.__endpoint,headers=headers,data = xml_content)

        if response.status_code != 200:
            raise Exception("Error downloading data:\n%s" % (response.text))

        return response.text
    
    def __xmlbatch_to_pandas(self,xml_content,tag_dict,date_batches,include_units):
        """ Get DataFrame from XML raw data batch in long mode

        param xml_content: XML raw data extarcted from PI
        param tag_dict: dict to make tag maping
        return pandas dataframe with extracted data in long mode
        """


        # Access requested data
        try:
            root = etree.fromstring(xml_content)
            item_list = root.getchildren()[0].getchildren()[0].getchildren()[0].getchildren()

            df_final = None
            for item in item_list:

                # Get tag
                tag = item.attrib['Path'].split("\\")[-1]
                tag_value = "%s|%s" % (tag_dict[tag],tag)
                

                if not 'ErrDesc' in item.attrib: # Downloaded data

                    if include_units:
                        tag_value += "|%s" % (item.attrib['UOM'])
                    
                    # Parse data
                    raw_data = item.getchildren()[0].getchildren()
                    aux_dict = {}
                    aux_dict['time'] = [item2.attrib['Time'] for item2 in raw_data]
                    aux_dict['value'] = [item3.text for item3 in raw_data]
                    df_aux = pd.DataFrame(aux_dict)

                    df_aux.loc[:,'tag'] = tag_value
                    
                
                else: # Error
                    # dt_from_local = pytz.timezone(self.__time_zone).localize(date_batches[0].replace(tzinfo=None))
                    # dt_from_utc = dt_from_local.astimezone(pytz.timezone("UTC"))
                    dt_from_local = date_batches[0].replace(tzinfo=None).replace(tzinfo = ZoneInfo(self.__time_zone))
                    dt_from_utc = dt_from_local.astimezone(ZoneInfo("UTC"))

                    error_msg = item.attrib['ErrDesc']
                    date_to_assign = dt.datetime(date_batches[0].year,
                        date_batches[0].month,
                        date_batches[0].day,
                        0,0,0,
                        #tzinfo=pytz.utc
                    )
                    date_to_assign = dt_from_utc.replace(tzinfo=None)
                    error_msg = "not found" if error_msg.split(".")[0] == "PIPoint not found" else error_msg
                    df_aux = pd.DataFrame({'time':[date_to_assign],'tag':[tag_value],'value':[error_msg]})

                    # print(df_aux)
                
                # Append data
                if type(df_final) != pd.DataFrame:
                    df_final = df_aux
                else:
                    # df_final = df_final.append(df_aux)
                    df_final = pd.concat([df_final, df_aux])
            

            # Remove Timezone 
            df_final['time'] = pd.to_datetime(df_final['time'])
            df_final['time'] = df_final['time'].dt.tz_localize(None)



            return df_final

        except Exception as e:

            try:
                msg = "%s\nMessage: %s" % (item.attrib['Error'],item.attrib['ErrDesc'])
                raise Exception(msg)
            except:
                raise e
    
    def __get_tag_descriptor_dict(self,tags):
        """ Get tag-descriptor dict to map

        param tags: tag list

        return dict with tag-descriptor maping
        """

        tag_dict = {}
        for tag in tags:
            tag_dict[tag['tag']] = tag['descriptor']
        
        return tag_dict
            

    def __read_values(self,download_mode,date_from,date_to,tag_list,time_interval=None,time_range_download=None,filter_expression=None,mode='long',include_units=False,calculation=None,calculation_time_tag=None,verbose=False,on_error_continue=False,on_error_attemps=10):
        """ Read values from PI Service Server

        param download_mode: download flag to download recorded or interpolated values.
        param date_from: datetime to get data from.
        param date_to: datetime to get data to.
        param tag_list: tag list in PI Data Archive or PI AF format.
        param time_interval: time frequency in PI Format.
        param filter_expression: (default None) filter expression for PI Data Servers.
        param mode: dataframe structure (long/wide).
        param calculation (default None): calculation Osisoft type if needed.
        param verbose: flag to indicate if verbosing output.
        param on_error_continue: flag to indicate if return results when a batch fails.

        return pandas dataframe with target data.
        """
        tag_dict = self.__get_tag_descriptor_dict(tag_list)
        tag_list = list(tag_dict.keys())

        # Get Batches
        # tag_batches, date_batches = self.__optimize_batch_size(date_from,date_to,time_interval,tag_list)
        # tag_batches, date_batches = self.__optimize_batch_multiple(download_mode,tag_list,date_from,date_to,time_interval)

        # Get date batches
        if time_range_download == "memory_saving":
            tag_batches, date_batches = self.__optimize_batch_multiple_range_download(download_mode,tag_list,date_from,date_to,time_interval)
        else:
            tag_batches, date_batches = self.__optimize_batch_multiple(download_mode,tag_list,date_from,date_to,time_interval)


        total_batches = len(tag_batches) * len(date_batches)
        if verbose:
            print("-------------------------------")
            print("Total tag batches: %d" % (len(tag_batches)))
            print("Total date batches per tag batch: %d" % (len(date_batches)))
            print("Total batches to download: %d" % (total_batches))
            print("-------------------------------")

        df_final = None
        # Process each batch
        batches_downloaded = 0
        i = 0
        for date_b in date_batches:
            
            # if i < len(date_batches)-1:
            #     date_b[-1] = date_b[-1].replace(hour=23,minute=59,second=59)

            i+=1

            df_tags = None
            for tag_b in tag_batches:
                start_time = time.time()
                
                downloaded = False
                attemp = 0
                # max_attemps = ConnectionErrorAttemps['max_attemps']
                max_attemps = on_error_attemps

                while not downloaded and attemp < max_attemps:
                    
                    try:
                        if calculation is None:
                            aux = self.__get_xml_batch_data(download_mode,tag_b,date_b,time_interval,filter_expression)
                        else:
                            aux = self.__get_xml_batch_data_calculated(download_mode,tag_b,date_b,time_interval,calculation,filter_expression,calculation_time_tag)
                        
                        df_aux = self.__xmlbatch_to_pandas(aux,tag_dict,date_b,include_units)

                        if type(df_tags) != pd.DataFrame:
                            df_tags = df_aux 
                        else:
                            # df_tags = df_tags.append(df_aux)
                            df_tags = pd.concat([df_tags, df_aux])

                        downloaded = True
                    except Exception as e:

                        if attemp >= (max_attemps-1):
                            if on_error_continue:
                                attemp += 1
                            else:
                                error_msg = "%s Max attemps exceeded when downloading data. Error:\n%s" % (ExceptionErrorCodes["read_error"],str(e))
                                raise DataReaderError(error_msg)
                        else:
                            attemp += 1
                            time.sleep(ConnectionErrorAttemps['time_to_sleep'])

                if verbose:
                    batches_downloaded += 1
                    print("[%d/%d] %s" % (batches_downloaded,total_batches,self.pretty_time(time.time()-start_time)))

            
            if type(df_final) != pd.DataFrame:
                df_final = df_tags
            else:
                # df_final = df_final.append(df_tags)
                df_final = pd.concat([df_final, df_tags])
        
        if verbose:
            print("-------------------------------")


        if type(df_final) == pd.DataFrame:

            df_final.drop(index=df_final.loc[df_final['time'].isna()].index,inplace=True)
            df_final['time'] = df_final['time'].values.astype('datetime64[s]')

            # For just a value remove API Duplicates
            df_final.drop_duplicates(['time','tag'],keep= 'first',inplace=True)

            # df_tags['value'] = df_tags['value'].apply(pd.to_numeric, errors='coerce')
            if mode == "wide":
                if download_mode == 'recorded' or (download_mode == "calculated" and calculation_time_tag == 'Auto'):
                    df_wide = pd.DataFrame()
                    for name,group in df_final.groupby("tag"):
                        group.drop(["tag"],axis=1,inplace=True)
                        group.rename(columns={"time":"time|%s"%(name),"value":name},inplace=True)
                        group.reset_index(inplace=True)
                        df_wide = pd.concat([df_wide,group],axis=1,join="outer")
                        df_wide.drop(columns=['index'],inplace=True)

                    df_final = df_wide
                    
                else:
                    not_nat = df_final.loc[~ pd.isnull(df_final.time)]
                    df_final.loc[pd.isnull(df_final.time),'time'] = not_nat.time.values[0]
                    df_final = df_final.pivot(values='value',index='time',columns = 'tag').reset_index()
                    # df_final = df_final.pivot_table(values='value',index='time',columns='tag',dropna=False).reset_index()
                    # del df_final.columns.name


            
            return df_final
        else:
            error_msg = "%s Wrong data returned from PI Web Service." % (ExceptionErrorCodes["data_error"])
            raise DataReaderError(error_msg)
    
    def pretty_time(self,seconds):
        """ Format seconds in hours, minutes and seconds string format

        param seconds: total seconds
        return string with hours, minutes and seconds format
        """

        pretty_str = ""
        s_aux = seconds

        # Parse hour
        if int(s_aux/3600) != 0:
            pretty_str += "%dh " % (int(s_aux/3600))
            s_aux = s_aux % 3600
        
        if int(s_aux/60) != 0:
            pretty_str += "%dm " % (int(s_aux/60))
            s_aux = s_aux % 60
        
        pretty_str += "%ds" % (s_aux)

        return pretty_str

    ### Asset Reader Access Functions
    #########################################################################
    
    def read_recorded_values(self,date_from,date_to,tag_list,time_interval="1s",time_range_download=None,filter_expression=None,mode='long',include_units=False,verbose=False,on_error_continue=False,on_error_attemps=10):
        """ Read recorded values from PIDA server

        Recorded values from PI Server will be always in long mode.

        param date_from: datetime to get data from.
        param date_to: datetime to get data to.
        param tag_list: tag list in PI Data Archive or PI AF format.
        
        return dataframe with requested values in long mode.
        """
        return self.__read_values('recorded',date_from,date_to,tag_list,time_interval=time_interval,time_range_download=time_range_download,filter_expression=filter_expression,mode=mode,include_units=include_units,verbose=verbose,on_error_continue=on_error_continue,on_error_attemps=on_error_attemps)

    
    def read_interpolated_values(self,date_from,date_to,tag_list,time_interval,time_range_download=None,filter_expression=None,mode='long',include_units=False,verbose=False,on_error_continue=False,on_error_attemps=10):
        """ Read interpolated values from PIDA Server

        param date_from: datetime to get data from.
        param date_to: datetime to get data to.
        param tag_list: tag list in PI Data Archive or PI AF format.
        param time_interval: time frequency in PI Format.
        param mode: dataframe structure (long/wide).
        """
        return self.__read_values('interpolated',date_from,date_to,tag_list,time_interval,time_range_download=time_range_download,filter_expression=filter_expression,mode=mode,include_units=include_units,verbose=verbose,on_error_continue=on_error_continue,on_error_attemps=on_error_attemps)
    
    def read_calculated_values(self,date_from,date_to,tag_list,time_interval,time_range_download=None,calculation=None,calculation_time_tag=None,filter_expression=None,mode='long',include_units=False,verbose=False,on_error_continue=False,on_error_attemps=10):
        """ Read calculated values from PIDA Server

        param date_from: datetime to get data from.
        param date_to: datetime to get data to.
        param tag_list: tag list in PI Data Archive or PI AF format.
        param calculation (default None): calculation Osisoft type if needed.
        param calculation_time_tag (default None): calculation Osisoft time type to download.
        param time_interval: time frequency in PI Format.
        param mode: dataframe structure (long/wide).
        """
        
        return self.__read_values('calculated',date_from,date_to,tag_list,time_interval,time_range_download=time_range_download,filter_expression=filter_expression,mode=mode,include_units=include_units,calculation=calculation,calculation_time_tag=calculation_time_tag,verbose=verbose,on_error_continue=on_error_continue,on_error_attemps=on_error_attemps)

        




        
        
    


