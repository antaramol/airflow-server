##################################################################
### PI Base Extractor
##################################################################

### Imports
##################################################################

# Generic imports
import json
import datetime as dt
import math
# import pytz
import pandas as pd
from zoneinfo import ZoneInfo

# Own imports
from AssetDataReader.extractor.BaseDataExtractor import BaseDataExtractor
# from osisoft.pidevclub.piwebapi.pi_web_api_client import PIWebApiClient
from osisoft.pidevclub.piwebapi.rest import ApiException

class PIDataExtractor(BaseDataExtractor):
    """ Atlantica Sustainable Infraestructure (ASI) PI Extractor

    This class serves as generic class which implements common methods used
    by PI Extractors
    """


    def __init__(self):
        """ Class constructor
        """
        pass

    def _convert_tz_to_pitz(self,pytz_tz):
        """ Convert PYTZ timezone name to PI timezone name.

        param pytz_tz: timezone in PYTZ name.

        return time zone in PI timezone name.
        """
        if pytz_tz == 'US/Pacific':
            return "Pacific Standard Time"

        elif pytz_tz == 'US/Arizona':
            #return "Pacific Standard Time"
            return "US Mountain Standard Time"

        elif pytz_tz == 'America/Hermosillo':
            #return "Pacific Standard Time"
            return "US Mountain Standard Time"

        elif pytz_tz == 'America/Mexico_City':
            return "Central Standard Time (Mexico)"

        elif pytz_tz == 'Africa/Johannesburg':
            return "South Africa Standard Time"

        elif pytz_tz == 'Europe/Madrid':
            return "Central Europe Standard Time"
        
        elif pytz_tz == 'America/Montevideo':
            return "Montevideo Standard Time"
        
        elif pytz_tz == "Canada/Mountain":
            return "Mountain Standard Time"

        elif pytz_tz == "Chile/Continental":
            return "E. South America Standard Time"

        elif pytz_tz == "UTC":
            return "UTC"


    def _get_items_per_tag(self,time_interval):
        """ Get number of items per tag and day

        param time_sinterval: time frequency in PI format
        return total items per tag
        """

        time_def = time_interval[-1]
        time_val = time_interval[0:-1]

        if time_def == 's':
            total_items = (60*60*24) / float(time_val)
        elif time_def == 'm':
            total_items = (60*24) / float(time_val)
        elif time_def == 'h':
            total_items = 24 / float(time_val)
        elif time_def == 'd':
            total_items = 1
        else:
            total_items = 1

        return total_items
    
    def _get_seconds_per_item(self,time_interval):
        """ Get total seconds per item

        param time_sinterval: time frequency in PI format
        return total items per tag
        """

        time_def = time_interval[-1]
        time_val = time_interval[0:-1]

        if time_def == 's':
            total_seconds = float(time_val)
        elif time_def == 'm':
            total_seconds = 60 * float(time_val)
        elif time_def == 'h':
            total_seconds = 60 * 60 * float(time_val)
        elif time_def == 'd':
            total_seconds = 24 * 60 * 60 * float(time_val)
        else:
            total_seconds = 24 * 60 * 60 * float(time_val)
        

        return total_seconds

    def _get_date_range_list(self,date_from,date_to):
        """ Generate date range list

        param date_from: datetime to get data from.
        param date_to: datetime to get data to.
        return: dayly date range list
        """
        date_from_full_day = dt.datetime(date_from.year,date_from.month,date_from.day,0,0,0)
        date_to_full_day = dt.datetime(date_to.year,date_to.month,date_to.day,0,0,0)
        date_list = [date_from_full_day + dt.timedelta(days=x) for x in range((date_to_full_day-date_from_full_day).days + 1)]
        date_list[0]= date_from
        date_list[-1] = date_to

        return date_list


    # def _current_get(self,di):
    #     """ Apply function for getting values.
    #     param di: dataframe
    #     return dataframe Value column
    #     """
    #     try:
    #         value = di['Name']
    #         return value
    #     except Exception as e:
    #         if di is None:
    #             raise Exception("Bad error processing by Osisoft Python Client")
    #         else:
    #             return di

        
    def _current_get(self,di):
        """ Apply function for getting values.
        param di: dataframe
        return dataframe Value column
        """
        try:
            value = di['Name']
            return value
        except Exception as e:
            return di


    def _get_pi_server_type(self,sample_tag):
        """ Get PI Server type from tag

        Given a sample tag, check PI server type.

        param sample_tag: sample tag from tag list.

        return PI server type (da/af)
        """

        item_tag = sample_tag.split("\\")
        if len(item_tag) == 1:
            return "da"
        else:
            return "af"





        
        
    


