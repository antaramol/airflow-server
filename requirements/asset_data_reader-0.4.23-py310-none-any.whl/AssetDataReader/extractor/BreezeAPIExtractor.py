##################################################################
### PI Web API Extractor
##################################################################


### Imports
##################################################################

# Generic imports
import json
import datetime as dt
import math
# import pytz
import pandas as pd
import time
import requests
from zoneinfo import ZoneInfo

# Own imports
from AssetDataReader.extractor.BaseDataExtractor import BaseDataExtractor

from AssetDataReader.config.Config import ConnectionErrorAttemps
from AssetDataReader.config.Config import BreezeConfig

from AssetDataReader.util.exceptions import ExceptionErrorCodes
from AssetDataReader.util.exceptions import DataReaderError


class BreezeAPIExtractor(BaseDataExtractor):
    """ Atlantica Sustainable Infraestructure (ASI) Breeze Extractor

    This class serves as a extractor from Breeze servers.
    """


    def __init__(self,asset_definition):
        """ Class constructor

        param asset_definition: asset definition for creating
        """

        if asset_definition['type'] != 'breeze_api':
            error_msg = "%s Asset type not correspond with class." % (ExceptionErrorCodes["invalid_asset"])
            raise DataReaderError(error_msg)
        else:

            # Get data from definition
            self.__asset_id = asset_definition['id']
            self.__windfarm = asset_definition['windfarm']
            self.__api_url = asset_definition['api_url']
            self.__api_key = asset_definition['api_key']
    
    
    def pretty_time(self,seconds):
        """ Format seconds in hours, minutes and seconds string format

        param seconds: total seconds
        return string with hours, minutes and seconds format
        """

        pretty_str = ""
        s_aux = seconds

        # Parse hour
        if int(s_aux/3600) != 0:
            pretty_str += "%dh " % (int(s_aux/3600))
            s_aux = s_aux % 3600
        
        if int(s_aux/60) != 0:
            pretty_str += "%dm " % (int(s_aux/60))
            s_aux = s_aux % 60
        
        pretty_str += "%ds" % (s_aux)

        return pretty_str


    def __call_breeze_api(self,end_url,parameters):
        """ Call Breeze API to extract data

        param end_url: final url expression to add to base url
        param parameters: list with parameters
        
        return API response
        """

        # Prepare URL
        target_url = self.__api_url + end_url

        first = True
        for parameter in parameters:
            if first:
                target_url += "?%s=%s" % (parameter['key'],parameter['value'])
                first = False
            else:
                target_url += "&%s=%s" % (parameter['key'],parameter['value'])
        
        # Prepare header
        headers = {'Breeze-ApiToken': self.__api_key}
        
        # Call API
        resp = requests.get(target_url, headers=headers)

        # Check for errors
        if resp.status_code != 200:

            if resp.status_code == 400:
                error_msg = "%s One or more parameters are wrong. Breeze API returns Bad Request (%d)" % (ExceptionErrorCodes["breeze_extractor_error"],resp.status_code)
            elif resp.status_code == 401:
                error_msg = "%s Breeze API Token is wrong. Breeze API returns Unauthorized (%d)" % (ExceptionErrorCodes["breeze_extractor_error"],resp.status_code)
            else:
                error_msg = "%s Breeze API fails (%d)" % (ExceptionErrorCodes["breeze_extractor_error"],resp.status_code)

            raise DataReaderError(error_msg)

        return resp
        
        
    def __get_devices_ids(self,tag_list):
        """ Get device ids for extraction

        param tag_list: tag list with target devices

        return dict with device title and id
        """
        
        # Get unique devices
        device_list = [x['tag'].split("|")[0] for x in tag_list]
        device_list = list(dict.fromkeys(device_list))

        # Get all device ids
        parameters = [
            {'key':"pageSize","value":"100"}
        ]
        resp = self.__call_breeze_api("devices.json",parameters)

        # Process response
        df_devices = pd.DataFrame.from_records(resp.json())
        device_dict = {}
        not_found_list = []
        for device in device_list:
            try:
                device_dict[device] = df_devices.loc[df_devices.title == device,'deviceId'].values[0]
            except:
                not_found_list.append(device)
        
        # if not_found_list or (not list(device_dict.keys())):
        #     error_msg = "%s Devices: [%s], not exist in Breeze Server" % (ExceptionErrorCodes["breeze_extractor_error"],",".join(not_found_list))
        #     raise DataReaderError(error_msg)
        
        return device_dict,not_found_list
    
    def __get_signal_ids(self,tag_list):
        """ Get signal ids for extraction

        param tag_list: tag list with target signals

        return dict with signal title and id
        """

        # Get unique signals
        signal_list = [x['tag'].split("|")[-1] for x in tag_list]
        signal_list = list(dict.fromkeys(signal_list))

        # Get all device ids
        parameters = [
            # {'key':"pageSize","value":"100"}
        ]
        resp = self.__call_breeze_api("datasignals.json",parameters)
        
        # Process response
        df_signals = pd.DataFrame.from_records(resp.json())

        signal_dict = {}
        not_found_list = []
        for signal in signal_list:
            try:
                signal_dict[signal] = {"id":df_signals.loc[df_signals.title == signal,'dataSignalId'].values[0],"unit":df_signals.loc[df_signals.title == signal,'unit'].values[0]}
            except:
                not_found_list.append(signal)

        # if not_found_list or (not list(signal_dict.keys())):
        #     error_msg = "%s Signals: [%s], not exist in Breeze Server" % (ExceptionErrorCodes["breeze_extractor_error"],",".join(not_found_list))
        #     raise DataReaderError(error_msg)


        return signal_dict,not_found_list
    


    def __get_data(self,date_from,date_to,time_interval,calculation,device_ids,signal_ids,include_units):
        """ Get data from devices

        param date_from: date to start download.
        param date_to: date to finish download.
        param time_interval: time step in Breeze format.
        param calculation: type of aggregation.
        param device_ids: list of target device to donwload.
        param signal_ids: list of target signals to donwload.

        return df with requested data.
        """

        # Get list of ids in str url format
        device_ids_list = str(list(device_ids.values()))[1:-1].replace(" ","")
        signal_ids_list = str([signal_ids[x]['id'] for x in signal_ids.keys()])[1:-1].replace(" ","")
        # signal_ids_list = ",".join([signal_ids[x]['id'] for x in signal_ids.keys()])


        # Check default calculation
        if calculation is None:
            calculation = 'sum'

        # Download data
        parameters = [
            {'key':"deviceIds","value":device_ids_list},
            {'key':"dataSignalIds","value":signal_ids_list},
            {'key':"timestampStart","value":date_from.strftime("%Y-%m-%dT%H:%M:%S")},
            {'key':"timestampEnd","value":date_to.strftime("%Y-%m-%dT%H:%M:%S")},
            {'key':"resolution","value":time_interval},
            {'key':"aggregate","value":"device"},
            {'key':"calculation","value":calculation}
        ]

        resp = self.__call_breeze_api("data.json",parameters)

        # Process response
        json_resp = resp.json()


        df_data = None
        for data in json_resp:

            df = pd.DataFrame.from_dict({"time":list(data['data'].keys()),"value":list(data['data'].values())})
            device_title = list(device_ids.keys())[list(device_ids.values()).index(data['aggregateId'])].replace(" ","_")
            # signal_title = list(signal_ids.keys())[list(signal_ids.values()).index(data['dataSignal']['dataSignalId'])].replace(" ","_")
            signal_title = list(signal_ids.keys())[[signal_ids[x]['id'] for x in signal_ids.keys()].index(data['dataSignal']['dataSignalId'])].replace(" ","_")
            
            
            tag_name = "%s|%s" % (device_title,signal_title)             
            if include_units:
                unit = signal_ids[signal_title.replace("_"," ")]['unit'] 
                tag_name += "|%s" % (unit)
            
            df['tag'] = tag_name

            if type(df_data) != pd.DataFrame:
                df_data = df
            else:
                # df_data = df_data.append(df,ignore_index=True)
                df_data = pd.concat([df_data, df], ignore_index=True)
        
        return df_data
    
    def __get_alarms(self,date_from,date_to,device_ids):
        """ Get alarms from devices

        param date_from: date to start download.
        param date_to: date to finish download.
        param device_ids: list of target device to donwload.

        return df with alarms codes.
        """

        # Get list of ids in str url format
        device_ids_list = str(list(device_ids.values()))[1:-1].replace(" ","")

        # Download data
        parameters = [
            {'key':"pageSize","value":"1000000"},
            {'key':"deviceIds","value":device_ids_list},
            {'key':"timestampStart","value":date_from.strftime("%Y-%m-%dT%H:%M:%S")},
            {'key':"timestampEnd","value":date_to.strftime("%Y-%m-%dT%H:%M:%S")},
            {'key':"sortBy","value":"timestampStart"},
            {'key':"sortAsc","value":"true"}
        ]

        resp = self.__call_breeze_api("alerts.json",parameters)

        # Process response

        df_data = pd.read_json(resp.text,orient='records')

        # with open("results.json","r") as f:
        #     resp = f.read()
        # Convert to DF
        if not df_data.empty:
            maps_ids =  {v: k for k, v in device_ids.items()}
            df_data['device_name'] = df_data['deviceId'].map(maps_ids)
            df_data = df_data[['ruleId','device_name','timestampStart','timestampEnd','message','details']]
            df_data.columns = ['rule_id','device','start_time','end_time','message','details']
            return df_data
        
        else:
            return pd.DataFrame()
    
    def __get_status(self,date_from,date_to,device_ids):
        """ Get status from devices

        param date_from: date to start download.
        param date_to: date to finish download.
        param device_ids: list of target device to donwload.

        return df with status codes.
        """

        # Get list of ids in str url format
        device_ids_list = str(list(device_ids.values()))[1:-1].replace(" ","")

        # Download data
        parameters = [
            {'key':"pageSize","value":"1000000"},
            {'key':"deviceIds","value":device_ids_list},
            {'key':"timestampStart","value":date_from.strftime("%Y-%m-%dT%H:%M:%S")},
            {'key':"timestampEnd","value":date_to.strftime("%Y-%m-%dT%H:%M:%S")},
            {'key':"sortBy","value":"timestampStart"},
            {'key':"sortAsc","value":"true"}
        ]

        resp = self.__call_breeze_api("status.json",parameters)


        ## Process response
        df_data = pd.read_json(resp.text,orient='records')

        ## Process substatus
        df_substatus = df_data.loc[df_data['subStatus'].apply(lambda x: len(x) > 0)].copy()
        df_to_append = pd.DataFrame()
        for index,row in df_substatus.iterrows():
            df_data.drop(index=index,inplace=True) # Remove parent because is the first child
            df_to_append_substatus = pd.DataFrame.from_dict(row['subStatus'])
            # df_to_append = df_to_append.append(df_to_append_substatus,ignore_index=True) # Add all children to append group
            df_to_append = pd.concat([df_to_append, df_to_append_substatus],ignore_index=True) # Add all children to append group
        if df_to_append.shape[0] > 0:
            # df_data = df_data.append(df_to_append[df_data.columns],ignore_index=True)
            df_data = pd.concat([df_data, df_to_append[df_data.columns]], ignore_index=True)
        
        ## Convert to DF
        if not df_data.empty:
            maps_ids =  {v: k for k, v in device_ids.items()}
            df_data['device_name'] = df_data['deviceId'].map(maps_ids)
            df_data = df_data[['turbineStatusId','code','device_name','timestampStart','timestampEnd','message','comment','lostProduction','category','categoryIec','categoryContract']]
            df_data.columns = ['turbine_status_id','code','device','start_time','end_time','message','comment','lostProduction','category','categoryIec','categoryContract']

            return df_data
        
        else:
            return pd.DataFrame()

    
    def __generate_batch_dates(self,date_from,date_to,interval):
        """ Gereate date range

        param date_from: start date
        param date_to: end date
        param interval: number of days for each batch

        return list with target batch date
        """

        current_date = date_from + dt.timedelta(days=interval)
        current_date = current_date.replace(hour=0,minute=0,second=0)
        batch = [[date_from,(date_from + dt.timedelta(days=interval-1)).replace(hour=23,minute=59,second=59)]]
        while current_date <= date_to:
            next_date = current_date + dt.timedelta(days=interval-1)
            next_date = next_date.replace(hour=23,minute=59,second=59)
            batch.append([current_date,next_date])
            current_date = current_date + dt.timedelta(days=interval)
        
        batch[-1][-1] = date_to

        return batch

    def __generate_batch_dates_time_range(self,date_from,date_to):
        """ Gereate date range for time range download

        param date_from: start date
        param date_to: end date

        return list with target batch date
        """

        # Get start and end time
        start_time = [date_from.hour,date_from.minute,date_from.second]
        end_time = [date_to.hour,date_to.minute,date_to.second]

        current_date = date_from.replace(hour=0,minute=0,second=0)
        batch = []
        while current_date <= date_to:
            batch.append([current_date.replace(hour=start_time[0],minute=start_time[1],second=start_time[2]),
                current_date.replace(hour=end_time[0],minute=end_time[1],second=end_time[1])])
            current_date = current_date + dt.timedelta(days=1)
        
        batch[-1][-1] = date_to

        return batch


    def __read_data(self,action,date_from,date_to,tag_list,time_interval="10minute",time_range_download=None,calculation="sum",mode="long",include_units=False,verbose=False,on_error_continue=False,on_error_attemps=10):
        """ Perform read action 

        param action: type of donwload (data,status,alarms).
        param date_from: str or datetime with start time to download.
        param date_to: str or datetime with end time to download.
        param tag_list: dict or file path (EXCEL or CSV) tag list to download.
        param time_interval: (default None)  time frequency expression in PI format. If not 
            None, interpolated values will be returned.
        param calculation: where to download interpolated or recorded data.
        param mode: (default long) dataframe structure format: long or wide.
        param verbose: flag to indicate if verbosing output.
        param on_error_continue: flag to indicate if return results when a batch fails.

        return dataframe with requested data
        """

        df_data = None

        attemp = 0
        # max_attemps = ConnectionErrorAttemps['max_attemps']
        max_attemps = on_error_attemps
        try:
            not_found_error = ""
            not_found_tag_list = []

            device_ids, not_found_devices = self.__get_devices_ids(tag_list)
            if not_found_devices or (not list(device_ids.keys())):
                not_found_error +="\n%s Devices: %s, not exist in Breeze Server" % (ExceptionErrorCodes["breeze_extractor_error"],",".join(not_found_devices))
                not_found_tag_list = list(filter(lambda x: x['tag'].split("|")[0] in not_found_devices,tag_list))
            
            if action == "data":
                signal_ids, not_found_signals = self.__get_signal_ids(tag_list)
                if not_found_signals or (not list(signal_ids.keys())):
                    not_found_error +="\n%s Signals: %s, not exist in Breeze Server" % (ExceptionErrorCodes["breeze_extractor_error"],",".join(not_found_signals))
                    not_found_tag_list += list(filter(lambda x: x['tag'].split("|")[1] in not_found_signals,tag_list))
            
            if not_found_error != "":
                raise DataReaderError(not_found_error)

        except Exception as e:

            if type(e) == DataReaderError:
                if not on_error_continue:
                    raise e
                
                else:
                    # Remove duplicates
                    not_found_tag_list = [dict(t) for t in {tuple(d.items()) for d in not_found_tag_list}]
                    not_found_dict = [{"time":date_from,"tag":"%s" % (x['tag']),"value":"not found"} for x in not_found_tag_list]
                    df_data = pd.DataFrame.from_dict(not_found_dict)
                    print(df_data)

            else:
                # raise Exception("asd")
                if attemp >= (max_attemps-1):
                    if on_error_continue:
                        return None
                    else:
                        error_msg = "%s Max attemps exceeded when downloading data." % (ExceptionErrorCodes["read_error"])
                        raise DataReaderError(error_msg)
                else:
                    attemp += 1
                    time.sleep(ConnectionErrorAttemps['time_to_sleep'])

        # Get batch

        if time_range_download == "memory_saving":
             batches = self.__generate_batch_dates_time_range(date_from,date_to)
        else:
            batches = self.__generate_batch_dates(date_from,date_to,BreezeConfig['max_days_per_batch'])

        # Download batches
         
        total_batches = len(batches)
        batches_downloaded = 0
        if verbose:
            print("-------------------------------")
            print("Total batches to download: %d" % (total_batches))
            print("-------------------------------")

        # Add batches
        
        for batch in batches:
            start_time = time.time()

            downloaded = False
            attemp = 0
            max_attemps = on_error_attemps # ConnectionErrorAttemps['max_attemps']
            while not downloaded and attemp < max_attemps:
                try:
                    if type(df_data) != pd.DataFrame:
                        if action == "data":
                            df_data = self.__get_data(batch[0],batch[1],time_interval,calculation,device_ids,signal_ids,include_units)
                        elif action == "status":
                            df_data = self.__get_status(batch[0],batch[1],device_ids)
                        elif action == "alarms":
                            df_data = self.__get_alarms(batch[0],batch[1],device_ids)
                    else:
                        if action == "data":
                            # df_data = df_data.append(self.__get_data(batch[0],batch[1],time_interval,calculation,device_ids,signal_ids,include_units),ignore_index=True)
                            df_data = pd.concat([df_data, self.__get_data(batch[0],batch[1],time_interval,calculation,device_ids,signal_ids,include_units)], ignore_index=True)
                        elif action == "status":
                            # df_data = df_data.append(self.__get_status(batch[0],batch[1],device_ids),ignore_index=True)
                            df_data = pd.concat([df_data, self.__get_status(batch[0],batch[1],device_ids)],ignore_index=True)
                        elif action == "alarms":
                            # df_data = df_data.append(self.__get_alarms(batch[0],batch[1],device_ids),ignore_index=True)
                            df_data = pd.concat([df_data, self.__get_alarms(batch[0],batch[1],device_ids)],ignore_index=True)
                    
                    downloaded = True
                except Exception as e:
                    if (type(e) == DataReaderError) and (not on_error_continue):
                        raise e
                    else:

                        if attemp >= (max_attemps-1):
                            if on_error_continue:
                                return None
                            else:
                                error_msg = "%s Max attemps exceeded when downloading data." % (ExceptionErrorCodes["read_error"])
                                raise DataReaderError(error_msg)
                        else:
                            attemp += 1
                            time.sleep(ConnectionErrorAttemps['time_to_sleep'])
            
            if verbose:
                    batches_downloaded += 1
                    print("[%d/%d] %s" % (batches_downloaded,total_batches,self.pretty_time(time.time()-start_time)))

        if verbose:
            print("-------------------------------")

        if type(df_data) == pd.DataFrame:

            # Remove not defined tags
            if action == "data":
                used_tags = [x['tag'].replace(" ","_") for x in tag_list]
                not_used_register = df_data['tag'].apply(lambda x: not (("|".join(x.split("|")[0:2])) in used_tags))
                df_data.drop(df_data.loc[not_used_register,:].index,axis=0,inplace=True)
            
            # Remove duplicated status
            if action == "status":
                df_data.drop_duplicates(subset=['turbine_status_id'],keep='first',inplace=True)
                # df_data_fields = df_data.drop_duplicates(subset=['code','device','start_time','end_time'],keep='first')

            # Remove duplicated alarms
            if action == "alarms":
                df_data.drop_duplicates(subset=['rule_id', 'device', 'start_time', 'end_time'],keep='first',inplace=True)

            # Pivot pandas dataframe if wide mode
            if mode == "wide" and action == "data":
                # df_data = pd.pivot_table(df_data,values='value',index='time',columns = 'tag').reset_index()
                # df_data = df_data.pivot(values='value',index='time',columns = 'tag').reset_index()
                not_nat = df_data.loc[~ pd.isnull(df_data.time)]
                df_data.loc[pd.isnull(df_data.time),'time'] = not_nat.time.values[0]
                df_data = df_data.pivot(values='value',index='time',columns = 'tag').reset_index()
            
            return df_data
          
        else:
            error_msg = "%s Wrong data returned from Breeze API." % (ExceptionErrorCodes["data_error"])
            raise DataReaderError(error_msg)

        

    ### Asset Reader Access Functions
    #########################################################################

    def read_status_values(self,date_from,date_to,tag_list,verbose=False,on_error_continue=False,on_error_attemps=10):
        """ Read status data from devices

        param date_from: str or datetime with start time to download.
        param date_to: str or datetime with end time to download.
        param tag_list: dict or file path (EXCEL or CSV) tag list to download.
        param verbose: flag to indicate if verbosing output.
        param on_error_continue: flag to indicate if return results when a batch fails.

        return dataframe with requested data
        """

        return self.__read_data("status",date_from,date_to,tag_list,verbose=verbose,on_error_continue=on_error_continue,on_error_attemps=on_error_attemps)

    
    def read_data_values(self,date_from,date_to,tag_list,time_interval,time_range_download,download_mode,mode,include_units,verbose,on_error_continue,on_error_attemps=10):
        """ Read data from Device and Signals in Breeze

        param date_from: str or datetime with start time to download.
        param date_to: str or datetime with end time to download.
        param tag_list: dict or file path (EXCEL or CSV) tag list to download.
        param time_interval: (default None)  time frequency expression in PI format. If not 
            None, interpolated values will be returned.
        param download_mode: where to download interpolated or recorded data.
        param mode: (default long) dataframe structure format: long or wide.
        param verbose: flag to indicate if verbosing output.
        param on_error_continue: flag to indicate if return results when a batch fails.

        return dataframe with requested data
        """

        return self.__read_data("data",date_from,date_to,tag_list,time_interval,time_range_download,download_mode,mode,include_units,verbose,on_error_continue,on_error_attemps=on_error_attemps)

    
    def read_alarms_values(self,date_from,date_to,tag_list,verbose=False,on_error_continue=False,on_error_attemps=10):
        """ Read alarms data from devices

        param date_from: str or datetime with start time to download.
        param date_to: str or datetime with end time to download.
        param tag_list: dict or file path (EXCEL or CSV) tag list to download.
        param verbose: flag to indicate if verbosing output.
        param on_error_continue: flag to indicate if return results when a batch fails.

        return dataframe with requested data
        """
        return self.__read_data("alarms",date_from,date_to,tag_list,verbose=verbose,on_error_continue=on_error_continue,on_error_attemps=on_error_attemps)
    
    